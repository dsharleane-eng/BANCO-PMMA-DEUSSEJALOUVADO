CREATE TABLE public.user_responses (
  id BIGSERIAL PRIMARY KEY,
  question_id INTEGER NOT NULL,
  user_answer TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL,
  mode TEXT NOT NULL,
  session_id TEXT,
  time_spent_ms INTEGER DEFAULT 0,
  answered_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX user_resp_qid_idx ON public.user_responses (question_id);
CREATE INDEX user_resp_mode_idx ON public.user_responses (mode);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_responses TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.user_responses_id_seq TO anon, authenticated;
GRANT ALL ON public.user_responses TO service_role;
ALTER TABLE public.user_responses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public access user_responses" ON public.user_responses FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.bookmarks (
  id BIGSERIAL PRIMARY KEY,
  question_id INTEGER NOT NULL UNIQUE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookmarks TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.bookmarks_id_seq TO anon, authenticated;
GRANT ALL ON public.bookmarks TO service_role;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public access bookmarks" ON public.bookmarks FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.exam_sessions (
  id TEXT PRIMARY KEY,
  mode TEXT NOT NULL,
  title TEXT NOT NULL,
  total_questions INTEGER NOT NULL,
  correct_count INTEGER NOT NULL,
  incorrect_count INTEGER NOT NULL,
  blank_count INTEGER NOT NULL,
  net_score REAL NOT NULL,
  percentage REAL NOT NULL,
  time_spent_seconds INTEGER NOT NULL,
  details_json TEXT,
  completed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.exam_sessions TO anon, authenticated;
GRANT ALL ON public.exam_sessions TO service_role;
ALTER TABLE public.exam_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public access exam_sessions" ON public.exam_sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);