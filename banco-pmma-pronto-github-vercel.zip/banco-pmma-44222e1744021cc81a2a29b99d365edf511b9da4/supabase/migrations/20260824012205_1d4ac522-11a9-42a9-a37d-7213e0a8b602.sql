DELETE FROM public.user_responses;
DELETE FROM public.bookmarks;
DELETE FROM public.exam_sessions;

ALTER TABLE public.user_responses ADD COLUMN user_id uuid NOT NULL;
ALTER TABLE public.bookmarks ADD COLUMN user_id uuid NOT NULL;
ALTER TABLE public.exam_sessions ADD COLUMN user_id uuid NOT NULL;

CREATE INDEX idx_user_responses_user_id ON public.user_responses(user_id);
CREATE INDEX idx_bookmarks_user_id ON public.bookmarks(user_id);
CREATE INDEX idx_exam_sessions_user_id ON public.exam_sessions(user_id);

CREATE UNIQUE INDEX idx_bookmarks_user_question ON public.bookmarks(user_id, question_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_responses TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookmarks TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.exam_sessions TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.user_responses_id_seq TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.bookmarks_id_seq TO authenticated;
GRANT ALL ON public.user_responses TO service_role;
GRANT ALL ON public.bookmarks TO service_role;
GRANT ALL ON public.exam_sessions TO service_role;

ALTER TABLE public.user_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own responses" ON public.user_responses FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users manage own bookmarks" ON public.bookmarks FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users manage own exam sessions" ON public.exam_sessions FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);