-- Lock down direct API access: all reads/writes go through trusted server routes (service role)
DROP POLICY IF EXISTS "public access bookmarks" ON public.bookmarks;
DROP POLICY IF EXISTS "public access exam_sessions" ON public.exam_sessions;
DROP POLICY IF EXISTS "public access user_responses" ON public.user_responses;

REVOKE ALL ON public.bookmarks FROM anon, authenticated;
REVOKE ALL ON public.exam_sessions FROM anon, authenticated;
REVOKE ALL ON public.user_responses FROM anon, authenticated;

REVOKE ALL ON SEQUENCE public.bookmarks_id_seq FROM anon, authenticated;
REVOKE ALL ON SEQUENCE public.user_responses_id_seq FROM anon, authenticated;

GRANT ALL ON public.bookmarks TO service_role;
GRANT ALL ON public.exam_sessions TO service_role;
GRANT ALL ON public.user_responses TO service_role;

ALTER TABLE public.bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_responses ENABLE ROW LEVEL SECURITY;