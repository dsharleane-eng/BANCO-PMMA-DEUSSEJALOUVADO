
import React, { useState, useEffect } from "react";
import {
  Database,
  RefreshCw,
  Search,
  Plus,
  FileText,
  CheckCircle,
  Download,
  Eye,
  SlidersHorizontal,
  Sparkles,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";

export function QuestionManager() {
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [search, setSearch] = useState("");
  const [discipline, setDiscipline] = useState("Todas");
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedQuestion, setSelectedQuestion] = useState<QuestionType | null>(null);

  const fetchDataset = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (discipline !== "Todas") params.set("discipline", discipline);
      if (search.trim()) params.set("search", search.trim());
      params.set("page", page.toString());
      params.set("limit", "15");

      const res = await apiFetch(`/api/questions?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setQuestions(data.questions || []);
        setTotal(data.total || 0);
        setTotalPages(data.totalPages || 1);
      }
    } catch (err) {
      console.error("Error fetching dataset:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDataset();
  }, [discipline, search, page]);

  const handleSeedDatabase = async () => {
    setSeeding(true);
    try {
      const res = await apiFetch("/api/seed", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        alert(data.message || "Banco de 2.000 questões verificado e povoado com sucesso!");
        fetchDataset();
      } else {
        alert("Erro ao povoar banco de dados: " + (data.error || "Desconhecido"));
      }
    } catch (err) {
      console.error("Seed error:", err);
    } finally {
      setSeeding(false);
    }
  };

  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(questions, null, 2);
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `PMMA_2026_Questoes_Pagina_${page}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 border border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Database className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-extrabold tracking-tight">Gestor do Banco de 2.000 Questões (PostgreSQL)</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            Inspeção direta, gerenciamento, verificação do banco de dados e exportação de itens em lote.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            disabled={seeding}
            onClick={handleSeedDatabase}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${seeding ? "animate-spin" : ""}`} />
            <span>{seeding ? "Sincronizando 2.000 Questões..." : "Verificar / Povoar 2.000 Questões"}</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> Exportar JSON
          </button>
        </div>
      </div>

      {/* Search & Discipline Filter Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={discipline}
            onChange={(e) => {
              setDiscipline(e.target.value);
              setPage(1);
            }}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 font-semibold text-slate-900 dark:text-slate-100"
          >
            <option value="Todas">Todas as Disciplinas</option>
            <option value="Língua Portuguesa">Língua Portuguesa</option>
            <option value="História do Maranhão">História do Maranhão</option>
            <option value="Geografia do Maranhão">Geografia do Maranhão</option>
            <option value="Raciocínio Lógico">Raciocínio Lógico</option>
            <option value="História do Brasil">História do Brasil</option>
            <option value="Geografia do Brasil">Geografia do Brasil</option>
            <option value="Legislação PMMA (Estatuto)">Legislação PMMA (Estatuto)</option>
            <option value="Informática">Informática</option>
          </select>
        </div>

        <div className="relative w-full sm:w-96">
          <input
            type="text"
            placeholder="Buscar por termo ou Nº da questão..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 pl-8 text-slate-900 dark:text-slate-100"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
        </div>
      </div>

      {/* Data Table */}
      {loading ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-sm text-slate-500 font-medium">Carregando itens do banco de dados...</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
                  <th className="p-3 w-16">Nº</th>
                  <th className="p-3">Disciplina</th>
                  <th className="p-3">Assunto</th>
                  <th className="p-3">Dificuldade</th>
                  <th className="p-3">Gabarito</th>
                  <th className="p-3">Enunciado / Afirmação</th>
                  <th className="p-3 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {questions.map((q) => (
                  <tr key={q.questionNumber} className="hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-colors">
                    <td className="p-3 font-mono font-bold text-slate-900 dark:text-slate-100">
                      #{q.questionNumber}
                    </td>
                    <td className="p-3 font-semibold text-emerald-700 dark:text-emerald-400">
                      {q.discipline}
                    </td>
                    <td className="p-3 text-slate-600 dark:text-slate-400 max-w-[150px] truncate">
                      {q.topic}
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">
                        {q.difficulty}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded font-extrabold text-[10px] ${
                        q.answer === "CERTO" ? "bg-emerald-100 text-emerald-800" : "bg-red-100 text-red-800"
                      }`}>
                        {q.answer}
                      </span>
                    </td>
                    <td className="p-3 text-slate-700 dark:text-slate-300 max-w-xs truncate">
                      {q.statement}
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => setSelectedQuestion(q)}
                        className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded font-semibold text-[11px] flex items-center gap-1 ml-auto"
                      >
                        <Eye className="w-3.5 h-3.5" /> Detalhes
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-mono">
            <span>Página {page} de {totalPages} ({total} questões filtradas)</span>

            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="px-3 py-1 rounded border border-slate-300 dark:border-slate-700 disabled:opacity-40"
              >
                Anterior
              </button>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="px-3 py-1 bg-emerald-600 text-white rounded font-bold disabled:opacity-40"
              >
                Próxima
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Question Details Modal */}
      {selectedQuestion && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
                QUESTÃO #{selectedQuestion.questionNumber} - Inspecção Detalhada
              </h3>
              <button
                onClick={() => setSelectedQuestion(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <strong>Disciplina:</strong> {selectedQuestion.discipline} | <strong>Assunto:</strong> {selectedQuestion.topic}
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded font-medium">
                "{selectedQuestion.statement}"
              </div>

              <div className="p-3 bg-slate-900 text-white rounded flex justify-between font-bold">
                <span>Gabarito: {selectedQuestion.answer}</span>
                <span>Fonte: {selectedQuestion.source}</span>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded border border-amber-200">
                <strong>Onde está a pegadinha:</strong> {selectedQuestion.trap}
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded">
                <strong>Comentário:</strong> {selectedQuestion.explanation}
              </div>
            </div>

            <button
              onClick={() => setSelectedQuestion(null)}
              className="w-full py-2 bg-slate-800 text-white rounded-lg text-xs font-bold"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
