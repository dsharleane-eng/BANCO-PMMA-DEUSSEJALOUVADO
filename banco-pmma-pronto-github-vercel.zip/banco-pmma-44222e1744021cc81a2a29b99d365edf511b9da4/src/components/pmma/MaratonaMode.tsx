
import React, { useState, useEffect } from "react";
import { QuestionCard, QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";
import {
  Flame,
  Award,
  Zap,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  Trophy,
  ShieldCheck,
  ChevronRight
} from "lucide-react";

export function MaratonaMode() {
  const [currentQuestion, setCurrentQuestion] = useState<QuestionType | null>(null);
  const [loading, setLoading] = useState(true);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [totalAttempted, setTotalAttempted] = useState(0);
  const [totalCorrect, setTotalCorrect] = useState(0);
  const [userChoice, setUserChoice] = useState<"CERTO" | "ERRADO" | null>(null);
  const [showResult, setShowResult] = useState(false);

  const fetchRandomHardQuestion = async () => {
    setLoading(true);
    setUserChoice(null);
    setShowResult(false);
    try {
      const params = new URLSearchParams();
      params.set("mode", "MARATONA");
      params.set("limit", "1");
      params.set("random", "true");

      const res = await apiFetch(`/api/questions?${params.toString()}`);
      const data = await res.json();

      if (res.ok && data.questions && data.questions.length > 0) {
        setCurrentQuestion(data.questions[0]);
      }
    } catch (err) {
      console.error("Error fetching marathon question:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRandomHardQuestion();
  }, []);

  const handleMaratonaAnswer = async (choice: "CERTO" | "ERRADO") => {
    if (!currentQuestion || showResult) return;

    setUserChoice(choice);
    setShowResult(true);
    setTotalAttempted((prev) => prev + 1);

    const isCorrect = choice === currentQuestion.answer;

    if (isCorrect) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      if (newStreak > bestStreak) {
        setBestStreak(newStreak);
      }
      setTotalCorrect((prev) => prev + 1);
    } else {
      setStreak(0); // Reset streak on mistake
    }

    // Log attempt to database
    try {
      await apiFetch("/api/responses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionId: currentQuestion.questionNumber,
          userAnswer: choice,
          mode: "MARATONA"
        })
      });
    } catch (err) {
      console.error("Error saving marathon response:", err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Marathon Header Banner with Live Streak */}
      <div className="bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 text-white rounded-2xl p-6 border border-red-900 shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-6 h-6 text-amber-500 fill-amber-500 animate-bounce" />
            <h2 className="text-xl font-extrabold tracking-tight">Modo Maratona CEBRASPE Hardcore</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed max-w-xl">
            Desafio ininterrupto com questões de nível <span className="text-amber-400 font-bold">Avançado e Extremamente Difícil/Pegadinhas</span>. Mantenha sua sequência de acertos e supere seu recorde!
          </p>
        </div>

        {/* Live Streak Metrics */}
        <div className="flex items-center gap-3">
          <div className="bg-slate-900/90 border border-amber-500/40 p-3 rounded-xl text-center min-w-[100px]">
            <span className="block text-2xl font-black text-amber-400 flex items-center justify-center gap-1">
              <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
              {streak}
            </span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Sequência</span>
          </div>

          <div className="bg-slate-900/90 border border-slate-700 p-3 rounded-xl text-center min-w-[100px]">
            <span className="block text-2xl font-black text-emerald-400 flex items-center justify-center gap-1">
              <Trophy className="w-5 h-5 text-emerald-400" />
              {bestStreak}
            </span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Recorde</span>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-sm text-slate-500 font-medium">Carregando próxima questão difícil...</p>
        </div>
      ) : currentQuestion ? (
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 border border-slate-200 dark:border-slate-800 shadow-lg space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold px-2.5 py-1 bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 rounded border border-amber-300">
                  QUESTÃO #{currentQuestion.questionNumber}
                </span>
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {currentQuestion.discipline}
                </span>
              </div>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-300">
                {currentQuestion.difficulty}
              </span>
            </div>

            <div className="text-xs text-slate-500">
              <strong>Assunto:</strong> {currentQuestion.topic} ({currentQuestion.subtopic})
            </div>

            {currentQuestion.textContext && (
              <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs leading-relaxed font-serif border border-slate-200 dark:border-slate-800">
                {currentQuestion.textContext}
              </div>
            )}

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 text-sm font-medium text-slate-900 dark:text-slate-100 leading-relaxed border border-slate-200 dark:border-slate-700">
              "{currentQuestion.statement}"
            </div>

            {/* Answer Buttons */}
            {!showResult ? (
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => handleMaratonaAnswer("CERTO")}
                  className="py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>CERTO</span>
                </button>

                <button
                  onClick={() => handleMaratonaAnswer("ERRADO")}
                  className="py-4 bg-red-600 hover:bg-red-700 text-white font-extrabold text-base rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <XCircle className="w-5 h-5" />
                  <span>ERRADO</span>
                </button>
              </div>
            ) : (
              <div className="space-y-4 animate-fadeIn">
                <div className={`p-4 rounded-xl border flex items-center justify-between font-bold text-sm ${
                  userChoice === currentQuestion.answer
                    ? "bg-emerald-50 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200"
                    : "bg-red-50 text-red-900 border-red-300 dark:bg-red-950 dark:text-red-200"
                }`}>
                  <div className="flex items-center gap-2">
                    {userChoice === currentQuestion.answer ? (
                      <>
                        <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                        <span>ACERTOU! SEQUÊNCIA ATUAL: {streak} 🔥</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-6 h-6 text-red-600" />
                        <span>ERROU! SEQUÊNCIA ZERADA.</span>
                      </>
                    )}
                  </div>
                  <span className="font-mono text-xs">Gabarito: {currentQuestion.answer}</span>
                </div>

                <div className="p-4 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-xs space-y-1">
                  <h6 className="font-bold text-amber-900 dark:text-amber-300">PEGADINHA DO ITEM:</h6>
                  <p className="text-amber-900/90 dark:text-amber-200">{currentQuestion.trap}</p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
                  <strong>Explicação:</strong> {currentQuestion.explanation}
                </div>

                <button
                  onClick={fetchRandomHardQuestion}
                  className="w-full py-4 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <span>PRÓXIMA QUESTÃO HARDCORE</span>
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
