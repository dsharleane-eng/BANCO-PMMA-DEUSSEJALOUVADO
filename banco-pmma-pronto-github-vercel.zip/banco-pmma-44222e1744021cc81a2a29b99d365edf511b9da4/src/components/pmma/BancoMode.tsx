
import React, { useState, useEffect, useCallback } from "react";
import { QuestionCard, QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";
import {
  Filter,
  Search,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  CheckCircle,
  HelpCircle,
  Sparkles,
  SlidersHorizontal,
  RefreshCw,
  Hash
} from "lucide-react";

const DISCIPLINES = [
  "Todas",
  "Língua Portuguesa",
  "História do Maranhão",
  "Geografia do Maranhão",
  "Raciocínio Lógico",
  "História do Brasil",
  "Geografia do Brasil",
  "Legislação PMMA (Estatuto)",
  "Informática"
];

const DIFFICULTIES = ["Todas", "Difícil", "Muito Difícil", "Avançado", "Extremamente Difícil"];

const STATUS_FILTERS = [
  { id: "all", label: "Todas as Questões" },
  { id: "unanswered", label: "Não Respondidas" },
  { id: "wrong", label: "Incorretas / Erros" },
  { id: "bookmarked", label: "Marcadas com Estrela" },
];

export function BancoMode() {
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDiscipline, setSelectedDiscipline] = useState("Todas");
  const [selectedTopic, setSelectedTopic] = useState("Todos");
  const [selectedDifficulty, setSelectedDifficulty] = useState("Todas");
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [questionNumberInput, setQuestionNumberInput] = useState("");
  
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const [availableTopics, setAvailableTopics] = useState<string[]>([]);

  // Fetch Questions
  const fetchQuestions = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedDiscipline !== "Todas") params.set("discipline", selectedDiscipline);
      if (selectedTopic !== "Todos") params.set("topic", selectedTopic);
      if (selectedDifficulty !== "Todas") params.set("difficulty", selectedDifficulty);
      if (filterStatus !== "all") params.set("filterStatus", filterStatus);
      if (searchQuery.trim()) params.set("search", searchQuery.trim());
      if (questionNumberInput.trim()) params.set("questionNumber", questionNumberInput.trim());

      params.set("page", page.toString());
      params.set("limit", limit.toString());
      params.set("mode", "BANCO");

      const res = await apiFetch(`/api/questions?${params.toString()}`);
      const data = await res.json();

      if (res.ok) {
        setQuestions(data.questions || []);
        setTotalQuestions(data.total || 0);
        setTotalPages(data.totalPages || 1);
      }
    } catch (err) {
      console.error("Error fetching questions:", err);
    } finally {
      setLoading(false);
    }
  }, [selectedDiscipline, selectedTopic, selectedDifficulty, filterStatus, searchQuery, questionNumberInput, page, limit]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  // Handle Response Submission to API
  const handleAnswerSubmit = async (questionNumber: number, userAnswer: "CERTO" | "ERRADO") => {
    try {
      await apiFetch("/api/responses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionId: questionNumber,
          userAnswer,
          mode: "BANCO"
        })
      });
    } catch (err) {
      console.error("Error saving response:", err);
    }
  };

  // Handle Bookmark Toggle
  const handleToggleBookmark = async (questionNumber: number) => {
    try {
      await apiFetch("/api/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionId: questionNumber })
      });
    } catch (err) {
      console.error("Error toggling bookmark:", err);
    }
  };

  const handleClearFilters = () => {
    setSelectedDiscipline("Todas");
    setSelectedTopic("Todos");
    setSelectedDifficulty("Todas");
    setFilterStatus("all");
    setSearchQuery("");
    setQuestionNumberInput("");
    setPage(1);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 border border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-extrabold tracking-tight">Banco de Questões PMMA 2026</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            Navegue pelas <span className="text-emerald-400 font-bold">2.000 questões inéditas e comentadas</span> no padrão estrito da CEBRASPE (Certo/Errado). Risque trechos falsos e consulte os comentários com a pegadinha identificada.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-700 text-xs font-mono">
          <span className="text-slate-400">Total Filtrado:</span>
          <span className="text-emerald-400 font-extrabold text-sm">{totalQuestions} itens</span>
        </div>
      </div>

      {/* Filter Control Box */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-slate-100">
            <SlidersHorizontal className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>Filtros Estratégicos de Estudo</span>
          </div>
          <button
            onClick={handleClearFilters}
            className="text-xs text-slate-500 hover:text-emerald-600 dark:hover:text-emerald-400 font-medium flex items-center gap-1"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Limpar Filtros
          </button>
        </div>

        {/* Filter Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {/* Discipline Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Disciplina:
            </label>
            <select
              value={selectedDiscipline}
              onChange={(e) => {
                setSelectedDiscipline(e.target.value);
                setSelectedTopic("Todos");
                setPage(1);
              }}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 font-medium text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
            >
              {DISCIPLINES.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          {/* Difficulty Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nível de Dificuldade:
            </label>
            <select
              value={selectedDifficulty}
              onChange={(e) => {
                setSelectedDifficulty(e.target.value);
                setPage(1);
              }}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 font-medium text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
            >
              {DIFFICULTIES.map((diff) => (
                <option key={diff} value={diff}>
                  {diff}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Status da Questão:
            </label>
            <select
              value={filterStatus}
              onChange={(e) => {
                setFilterStatus(e.target.value);
                setPage(1);
              }}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 font-medium text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
            >
              {STATUS_FILTERS.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          {/* Direct Question Number Lookup */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Ir para Questão Nº:
            </label>
            <div className="relative">
              <input
                type="number"
                placeholder="Ex: 452 (1 a 2000)"
                min="1"
                max="2000"
                value={questionNumberInput}
                onChange={(e) => {
                  setQuestionNumberInput(e.target.value);
                  setPage(1);
                }}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-2.5 pl-8 font-mono text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
              />
              <Hash className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
            </div>
          </div>
        </div>

        {/* Text Keyword Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Pesquisar por palavras-chave no enunciado, comentário ou pegadinha (ex: Batalha de Guaxenduba, Leis de De Morgan, ITAQUI)..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-3 pl-9 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
        </div>
      </div>

      {/* Questions List */}
      {loading ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-sm text-slate-500 font-medium">Carregando questões do Banco de dados...</p>
        </div>
      ) : questions.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6">
          <HelpCircle className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">Nenhuma questão encontrada com esses filtros</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Tente remover a busca por palavra-chave ou selecionar outra disciplina/status para visualizar mais itens do banco.
          </p>
          <button
            onClick={handleClearFilters}
            className="mt-2 text-xs font-semibold px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
          >
            Resetar Filtros
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {questions.map((q) => (
            <QuestionCard
              key={q.questionNumber}
              question={q}
              onAnswerSubmit={(ans) => handleAnswerSubmit(q.questionNumber, ans)}
              onToggleBookmark={handleToggleBookmark}
            />
          ))}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <div className="text-xs text-slate-500 font-mono">
                Página <span className="font-bold text-slate-900 dark:text-slate-100">{page}</span> de{" "}
                <span className="font-bold text-slate-900 dark:text-slate-100">{totalPages}</span> ({totalQuestions} questões no filtro)
              </div>

              <div className="flex items-center gap-2">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage(page - 1)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  <ChevronLeft className="w-4 h-4" /> Anterior
                </button>

                <div className="flex items-center gap-1 overflow-x-auto max-w-[200px] sm:max-w-none">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum = page;
                    if (page <= 3) pageNum = i + 1;
                    else if (page >= totalPages - 2) pageNum = totalPages - 4 + i;
                    else pageNum = page - 2 + i;

                    if (pageNum < 1 || pageNum > totalPages) return null;

                    return (
                      <button
                        key={pageNum}
                        onClick={() => setPage(pageNum)}
                        className={`w-8 h-8 rounded-lg text-xs font-bold ${
                          page === pageNum
                            ? "bg-emerald-600 text-white"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                </div>

                <button
                  disabled={page >= totalPages}
                  onClick={() => setPage(page + 1)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1"
                >
                  Próxima <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
