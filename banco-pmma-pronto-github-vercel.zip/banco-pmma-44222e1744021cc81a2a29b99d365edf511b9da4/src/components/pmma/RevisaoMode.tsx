import React, { useEffect, useState } from "react";
import { QuestionCard, QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";
import {
  RotateCcw,
  AlertTriangle,
  HelpCircle,
  Eye,
  ChevronRight,
  ChevronLeft,
  RotateCw,
  Brain,
  Clock3,
  Sparkles,
  CheckCircle2,
} from "lucide-react";

type FlashcardItem = {
  question: QuestionType;
  card: {
    ease: number;
    intervalDays: number;
    repetitions: number;
    lapses: number;
    dueAt: string | null;
    isNew: boolean;
  };
};

type FlashcardStats = {
  totalCards: number;
  dueCount: number;
  newCount: number;
  learning: number;
  mature: number;
  reviewsToday: number;
};

const emptyFlashStats: FlashcardStats = {
  totalCards: 0,
  dueCount: 0,
  newCount: 0,
  learning: 0,
  mature: 0,
  reviewsToday: 0,
};

export function RevisaoMode() {
  const [tab, setTab] = useState<"wrong" | "bookmarked" | "flashcard">("wrong");
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [loading, setLoading] = useState(true);
  const [flashcards, setFlashcards] = useState<FlashcardItem[]>([]);
  const [flashStats, setFlashStats] = useState<FlashcardStats>(emptyFlashStats);
  const [flashIndex, setFlashIndex] = useState(0);
  const [showFlashAnswer, setShowFlashAnswer] = useState(false);
  const [ratingLoading, setRatingLoading] = useState(false);
  const [flashError, setFlashError] = useState<string | null>(null);

  const fetchReviewQuestions = async (type: "wrong" | "bookmarked") => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("filterStatus", type);
      params.set("mode", "REVISAO");
      params.set("limit", "100");

      const res = await apiFetch(`/api/questions?${params.toString()}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Não foi possível carregar a revisão.");

      setQuestions(data.questions || []);
    } catch (err) {
      console.error("Error fetching review questions:", err);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchFlashcards = async () => {
    setLoading(true);
    setFlashError(null);
    try {
      const res = await apiFetch("/api/flashcards?dueLimit=40&newLimit=40", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Não foi possível carregar os flashcards.");

      setFlashcards(data.queue || []);
      setFlashStats(data.stats || emptyFlashStats);
      setFlashIndex(0);
      setShowFlashAnswer(false);
    } catch (err) {
      console.error("Error fetching flashcards:", err);
      setFlashcards([]);
      setFlashError(err instanceof Error ? err.message : "Erro ao carregar flashcards.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tab === "flashcard") fetchFlashcards();
    else fetchReviewQuestions(tab);
  }, [tab]);

  const currentFlashcard = flashcards[flashIndex];

  const rateFlashcard = async (rating: "again" | "hard" | "good" | "easy") => {
    if (!currentFlashcard || ratingLoading) return;
    setRatingLoading(true);
    try {
      const res = await apiFetch("/api/flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          questionId: currentFlashcard.question.questionNumber,
          rating,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "Não foi possível salvar a avaliação.");

      // Remove the rated card from the current queue so the user never gets
      // stuck on the same card after rating it.
      setFlashcards((prev) => prev.filter((_, index) => index !== flashIndex));
      setFlashStats((prev) => ({
        ...prev,
        totalCards: Math.max(0, prev.totalCards + (currentFlashcard.card.isNew ? 1 : 0)),
        dueCount: Math.max(0, prev.dueCount - (currentFlashcard.card.isNew ? 0 : 1)),
        newCount: Math.max(0, prev.newCount - (currentFlashcard.card.isNew ? 1 : 0)),
        reviewsToday: prev.reviewsToday + 1,
      }));
      setFlashIndex((prev) => Math.min(prev, Math.max(0, flashcards.length - 2)));
      setShowFlashAnswer(false);
    } catch (err) {
      console.error("Error rating flashcard:", err);
      setFlashError(err instanceof Error ? err.message : "Erro ao salvar avaliação.");
    } finally {
      setRatingLoading(false);
    }
  };

  const moveFlashcard = (delta: number) => {
    setFlashIndex((prev) => Math.min(Math.max(0, prev + delta), Math.max(0, flashcards.length - 1)));
    setShowFlashAnswer(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-6 border border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <RotateCcw className="w-5 h-5 text-indigo-400" />
            <h2 className="text-xl font-extrabold tracking-tight">Modo Revisão Inteligente PMMA</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            Revise erros, questões salvas e use repetição espaçada para transformar seus pontos fracos em acertos.
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-xl border border-slate-700">
          <button onClick={() => setTab("wrong")} className={`px-3 py-1.5 rounded-lg text-xs font-bold ${tab === "wrong" ? "bg-indigo-600 text-white shadow-md" : "text-slate-300 hover:text-white hover:bg-slate-800"}`}>Questões Incorretas</button>
          <button onClick={() => setTab("bookmarked")} className={`px-3 py-1.5 rounded-lg text-xs font-bold ${tab === "bookmarked" ? "bg-indigo-600 text-white shadow-md" : "text-slate-300 hover:text-white hover:bg-slate-800"}`}>Marcadas / Salvas</button>
          <button onClick={() => setTab("flashcard")} className={`px-3 py-1.5 rounded-lg text-xs font-bold ${tab === "flashcard" ? "bg-indigo-600 text-white shadow-md" : "text-slate-300 hover:text-white hover:bg-slate-800"}`}>Modo Flashcard</button>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm text-slate-500 font-medium">Carregando itens para revisão...</p>
        </div>
      ) : tab === "flashcard" ? (
        <div className="space-y-5">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {[
              ["Novos", flashStats.newCount, Sparkles],
              ["Vencidos", flashStats.dueCount, Clock3],
              ["Aprendendo", flashStats.learning, Brain],
              ["Maduros", flashStats.mature, CheckCircle2],
              ["Hoje", flashStats.reviewsToday, RotateCw],
            ].map(([label, value, Icon]) => {
              const I = Icon as React.ElementType;
              return (
                <div key={String(label)} className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4">
                  <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500 uppercase"><I className="w-3.5 h-3.5 text-indigo-500" />{label}</div>
                  <div className="text-xl font-black text-slate-900 dark:text-slate-100 mt-1">{value as number}</div>
                </div>
              );
            })}
          </div>

          {flashError && (
            <div className="p-4 rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 dark:border-red-900 text-sm text-red-700 dark:text-red-300">
              {flashError}
            </div>
          )}

          {!currentFlashcard ? (
            <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6">
              <Brain className="w-12 h-12 text-indigo-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">Nenhum flashcard para estudar agora.</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">Avalie os cartões durante o estudo. Os vencidos voltarão automaticamente na próxima revisão.</p>
              <button onClick={fetchFlashcards} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold">Atualizar fila</button>
            </div>
          ) : (
            <div className="max-w-2xl mx-auto space-y-5">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-mono font-bold">CARD {flashIndex + 1} / {flashcards.length}</span>
                <span className="font-semibold">{currentFlashcard.question.discipline}</span>
              </div>

              <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 md:p-8 border border-slate-200 dark:border-slate-800 shadow-lg space-y-5">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <span className={`text-xs font-mono font-bold px-3 py-1 rounded ${currentFlashcard.card.isNew ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300" : "bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300"}`}>
                    {currentFlashcard.card.isNew ? "NOVO" : "REVISÃO"}
                  </span>
                  <span className="text-xs text-slate-400">#{currentFlashcard.question.questionNumber}</span>
                </div>

                <div className="text-xs text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider">{currentFlashcard.question.topic}</div>
                <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium text-sm md:text-base leading-relaxed border border-slate-200 dark:border-slate-700">
                  {currentFlashcard.question.statement}
                </div>

                {!showFlashAnswer ? (
                  <button onClick={() => setShowFlashAnswer(true)} className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2">
                    <Eye className="w-5 h-5" /> REVELAR GABARITO E COMENTÁRIO
                  </button>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900 text-white">
                      <span className="text-xs text-slate-400 font-bold uppercase">Gabarito Oficial</span>
                      <span className={`px-3 py-0.5 rounded font-black text-sm ${currentFlashcard.question.answer === "CERTO" ? "bg-emerald-500" : "bg-red-500"}`}>{currentFlashcard.question.answer}</span>
                    </div>
                    <div className="p-4 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-xs space-y-2">
                      <h6 className="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4 text-amber-600" /> ONDE ESTÁ A PEGADINHA</h6>
                      <p className="text-amber-900/90 dark:text-amber-200 leading-relaxed">{currentFlashcard.question.trap}</p>
                    </div>
                    <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-800 text-xs leading-relaxed text-slate-800 dark:text-slate-200">
                      <strong>Comentário:</strong> {currentFlashcard.question.explanation}
                    </div>

                    <div className="pt-2">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-wide mb-2">Como foi sua lembrança?</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        <button disabled={ratingLoading} onClick={() => rateFlashcard("again")} className="py-3 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold disabled:opacity-50">ERREI / NOVAMENTE</button>
                        <button disabled={ratingLoading} onClick={() => rateFlashcard("hard")} className="py-3 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-extrabold disabled:opacity-50">DIFÍCIL</button>
                        <button disabled={ratingLoading} onClick={() => rateFlashcard("good")} className="py-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold disabled:opacity-50">BOM</button>
                        <button disabled={ratingLoading} onClick={() => rateFlashcard("easy")} className="py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-extrabold disabled:opacity-50">FÁCIL</button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                  <button disabled={flashIndex === 0 || ratingLoading} onClick={() => moveFlashcard(-1)} className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold disabled:opacity-40 flex items-center gap-1"><ChevronLeft className="w-4 h-4" /> Anterior</button>
                  <button disabled={flashIndex === flashcards.length - 1 || ratingLoading} onClick={() => moveFlashcard(1)} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 disabled:opacity-40 flex items-center gap-1">Próximo <ChevronRight className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : loading ? null : questions.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6">
          <HelpCircle className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">{tab === "wrong" ? "Nenhum erro registrado ainda!" : "Nenhuma questão salva com estrela!"}</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">Responda questões e favorize os itens que deseja revisar. Eles aparecerão aqui automaticamente.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {questions.map((q) => (
            <QuestionCard key={q.questionNumber} question={q} showExplanationInitially={true} />
          ))}
        </div>
      )}
    </div>
  );
}
