
import React, { useState, useEffect } from "react";
import { apiFetch } from "@/lib/apiFetch";
import {
  BarChart3,
  CheckCircle2,
  XCircle,
  Award,
  AlertTriangle,
  TrendingUp,
  Target,
  Trash2,
  RefreshCw,
  PieChart,
  Layers,
  BookOpen
} from "lucide-react";

export function AnalyticsDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchAnalytics = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await apiFetch("/api/analytics", { cache: "no-store" });
      const analytics = await res.json();
      if (res.ok) {
        setData(analytics);
      }
    } catch (err) {
      console.error("Error fetching analytics:", err);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
    // Mantém os dados sincronizados entre dispositivos, sem recarregar a página.
    const interval = setInterval(() => fetchAnalytics(true), 10000);
    const onFocus = () => fetchAnalytics(true);
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      clearInterval(interval);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, []);

  const handleResetStats = async () => {
    if (confirm("Deseja realmente zerar todo o seu histórico de desempenho e respostas? Esta ação não pode ser desfeita.")) {
      try {
        await apiFetch("/api/analytics", { method: "DELETE" });
        fetchAnalytics();
      } catch (err) {
        console.error("Error resetting stats:", err);
      }
    }
  };

  if (loading) {
    return (
      <div className="py-16 text-center space-y-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
        <p className="text-sm text-slate-500 font-medium">Calculando métricas e diagnósticos do Cebraspe...</p>
      </div>
    );
  }

  if (!data) return null;

  const totalQuestions = data.totalDatabaseQuestions ?? 0;
  const answered = data.uniqueAnsweredCount || 0;
  const percentageCompleted = Number(((answered / totalQuestions) * 100).toFixed(1));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 border border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-xl font-extrabold tracking-tight">Painel de Desempenho PMMA 2026</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
            Acompanhamento contínuo de acertos, erros, pontuação líquida e assuntos críticos que precisam de reforço urgente.
          </p>
        </div>

        <button
          onClick={handleResetStats}
          className="px-3.5 py-2 bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-800/80 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
        >
          <Trash2 className="w-3.5 h-3.5" /> Zerar Histórico
        </button>
      </div>

      {/* Main KPI Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
            <span>Pontuação Líquida</span>
            <Target className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-slate-900 dark:text-slate-100">
            {data.netScore}
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">Regra: +1 Certo, -1 Errado</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
            <span>Precisão Geral</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-emerald-600 dark:text-emerald-400">
            {data.accuracyPercentage}%
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">Meta PMMA: 80%+</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
            <span>Itens Resolvidos</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-slate-900 dark:text-slate-100">
            {answered} <span className="text-xs text-slate-400 font-normal">/ {totalQuestions}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">{percentageCompleted}% do Banco Coberto</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
            <span>Acertos vs Erros</span>
            <XCircle className="w-4 h-4 text-red-500" />
          </div>
          <div className="text-2xl md:text-3xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span className="text-emerald-600">{data.correctCount}</span>
            <span className="text-slate-300 dark:text-slate-700">/</span>
            <span className="text-red-500">{data.incorrectCount}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">Total de tentativas: {data.totalAnsweredAttempts}</p>
        </div>
      </div>

      {/* Progress Bar towards 2,000 Questions */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
          <span>Progresso do Banco</span>
          <span>{answered} de {totalQuestions} itens ({percentageCompleted}%)</span>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
          <div
            className="bg-emerald-600 h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, percentageCompleted)}%` }}
          />
        </div>
      </div>

      {/* Discipline Breakdown */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">
          Desempenho por Disciplina do Edital
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(data.disciplineStats || {}).map(([disc, stats]: [string, any]) => {
            const discPct = stats.total > 0 ? Number(((stats.correct / stats.total) * 100).toFixed(1)) : 0;

            return (
              <div key={disc} className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-200">
                  <span>{disc}</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400">{discPct}% ({stats.correct}/{stats.total})</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${discPct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
                  <span>Acertos: {stats.correct}</span>
                  <span>Erros: {stats.incorrect}</span>
                  <span>Líquido: {stats.correct - stats.incorrect}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weak Topics Focus Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Needs Review Topics */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-red-600 dark:text-red-400 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4" /> Assuntos com Maior Número de Erros (Revisar Urgênte)
          </h4>

          {data.needsReviewTopics && data.needsReviewTopics.length > 0 ? (
            <div className="space-y-2">
              {data.needsReviewTopics.map((item: any) => (
                <div key={item.topic} className="p-3 bg-red-50/50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-slate-900 dark:text-slate-100 block">{item.topic}</span>
                    <span className="text-[10px] text-slate-500">{item.discipline}</span>
                  </div>
                  <span className="font-mono font-bold text-red-600 dark:text-red-400">
                    {item.incorrect} erros ({item.percentage}%)
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic py-4">Nenhum ponto fraco crítico registrado ainda.</p>
          )}
        </div>

        {/* Mastered Topics */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
            <Award className="w-4 h-4" /> Assuntos Dominados (Aproveitamento {">"}= 80%)
          </h4>

          {data.masteredTopics && data.masteredTopics.length > 0 ? (
            <div className="space-y-2">
              {data.masteredTopics.map((item: any) => (
                <div key={item.topic} className="p-3 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-slate-900 dark:text-slate-100 block">{item.topic}</span>
                    <span className="text-[10px] text-slate-500">{item.discipline}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {item.percentage}% ({item.correct}/{item.total})
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic py-4">Siga respondendo questões para formar sua lista de assuntos dominados.</p>
          )}
        </div>
      </div>
    </div>
  );
}
