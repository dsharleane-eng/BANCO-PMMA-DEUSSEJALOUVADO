
import React, { useState } from "react";
import {
  CheckCircle2,
  XCircle,
  Bookmark,
  BookmarkCheck,
  AlertTriangle,
  Lightbulb,
  Check,
  Strikethrough,
  RotateCcw,
  FileText,
  ChevronDown,
  ChevronUp,
  Share2,
  Info
} from "lucide-react";

export interface QuestionType {
  id: number;
  questionNumber: number;
  discipline: string;
  topic: string;
  subtopic: string;
  difficulty: "Difícil" | "Muito Difícil" | "Avançado" | "Extremamente Difícil";
  textContext?: string | null;
  statement: string;
  answer: "CERTO" | "ERRADO";
  explanation: string;
  trap: string;
  correctForm: string;
  source: string;
  isBookmarked?: boolean;
  lastResponse?: { isCorrect: boolean; userAnswer: string } | null;
}

interface QuestionCardProps {
  question: QuestionType;
  showExplanationInitially?: boolean;
  onAnswerSubmit?: (userAnswer: "CERTO" | "ERRADO") => void;
  onToggleBookmark?: (questionNumber: number) => void;
  interactive?: boolean;
  userAnswer?: "CERTO" | "ERRADO" | null;
}

export function QuestionCard({
  question,
  showExplanationInitially = false,
  onAnswerSubmit,
  onToggleBookmark,
  interactive = true,
  userAnswer: externalUserAnswer = null,
}: QuestionCardProps) {
  const [userChoice, setUserChoice] = useState<"CERTO" | "ERRADO" | null>(
    externalUserAnswer || question.lastResponse?.userAnswer as "CERTO" | "ERRADO" | null || null
  );
  const [showExplanation, setShowExplanation] = useState(
    showExplanationInitially || Boolean(question.lastResponse)
  );
  const [isBookmarked, setIsBookmarked] = useState(Boolean(question.isBookmarked));
  const [showTextContext, setShowTextContext] = useState(true);
  const [struckWords, setStruckWords] = useState<Set<number>>(new Set());

  // Split statement into words for the strikeout tool feature
  const words = question.statement.split(" ");

  const toggleWordStrike = (index: number) => {
    setStruckWords((prev) => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  const clearStrikes = () => setStruckWords(new Set());

  const handleSelect = (choice: "CERTO" | "ERRADO") => {
    if (!interactive) return;
    setUserChoice(choice);
    setShowExplanation(true);
    if (onAnswerSubmit) {
      onAnswerSubmit(choice);
    }
  };

  const handleBookmarkToggle = () => {
    setIsBookmarked(!isBookmarked);
    if (onToggleBookmark) {
      onToggleBookmark(question.questionNumber);
    }
  };

  const difficultyColors = {
    "Difícil": "bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800",
    "Muito Difícil": "bg-orange-100 text-orange-800 border-orange-300 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800",
    "Avançado": "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800",
    "Extremamente Difícil": "bg-red-100 text-red-800 border-red-300 dark:bg-red-950/60 dark:text-red-300 dark:border-red-800",
  };

  const isCorrect = userChoice === question.answer;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow p-5 md:p-6 mb-6">
      {/* Header Info Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono font-bold text-xs bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 px-2.5 py-1 rounded-md">
            QUESTÃO #{question.questionNumber}
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800">
            {question.discipline}
          </span>
          <span className={`text-xs font-medium px-2 py-0.5 rounded border ${difficultyColors[question.difficulty] || "bg-slate-100 text-slate-700"}`}>
            {question.difficulty}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {struckWords.size > 0 && (
            <button
              onClick={clearStrikes}
              className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded"
              title="Limpar risco de palavras"
            >
              <RotateCcw className="w-3 h-3" />
              Limpar Riscos
            </button>
          )}

          <button
            onClick={handleBookmarkToggle}
            className={`p-1.5 rounded-lg border transition-colors flex items-center gap-1 text-xs ${
              isBookmarked
                ? "bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800"
                : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700"
            }`}
            title="Favoritar para revisão"
          >
            {isBookmarked ? (
              <>
                <BookmarkCheck className="w-4 h-4 text-amber-500 fill-amber-500" />
                <span className="font-medium hidden sm:inline">Salva</span>
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4" />
                <span className="hidden sm:inline">Favoritar</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Topics Breadcrumb */}
      <div className="text-xs text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5 flex-wrap">
        <span className="font-semibold text-slate-700 dark:text-slate-300">Assunto:</span>
        <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">{question.topic}</span>
        <span>•</span>
        <span className="italic">{question.subtopic}</span>
      </div>

      {/* Reading Text Context (collapsible if available) */}
      {question.textContext && (
        <div className="mb-4 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          <button
            onClick={() => setShowTextContext(!showTextContext)}
            className="w-full px-4 py-2 bg-slate-100/80 dark:bg-slate-800/80 text-left text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between"
          >
            <span className="flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              Texto de Apoio / Contexto de Referência
            </span>
            {showTextContext ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          {showTextContext && (
            <div className="p-4 text-xs md:text-sm leading-relaxed text-slate-700 dark:text-slate-300 border-t border-slate-200 dark:border-slate-800 font-serif whitespace-pre-line bg-amber-50/20 dark:bg-slate-900/40">
              {question.textContext}
            </div>
          )}
        </div>
      )}

      {/* Statement Area with Interactive Word Strikeout */}
      <div className="my-4 p-4 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
          <span>Julgue o item a seguir (Estilo CEBRASPE):</span>
          <span className="text-[10px] lowercase text-slate-400 font-normal flex items-center gap-1">
            <Strikethrough className="w-3 h-3" /> clique nas palavras para riscar
          </span>
        </div>

        <div className="text-sm md:text-base font-medium leading-relaxed text-slate-900 dark:text-slate-100">
          {words.map((word, idx) => (
            <span
              key={idx}
              onClick={() => toggleWordStrike(idx)}
              className={`cursor-pointer inline-block mr-1 my-0.5 px-0.5 rounded hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors ${
                struckWords.has(idx) ? "line-through text-red-400 dark:text-red-500 bg-red-50 dark:bg-red-950/30" : ""
              }`}
            >
              {word}
            </span>
          ))}
        </div>
      </div>

      {/* CERTO / ERRADO Action Buttons */}
      <div className="grid grid-cols-2 gap-3 my-5">
        <button
          disabled={!interactive}
          onClick={() => handleSelect("CERTO")}
          className={`py-3 px-4 rounded-xl font-bold text-sm md:text-base border transition-all flex items-center justify-center gap-2 ${
            userChoice === "CERTO"
              ? question.answer === "CERTO"
                ? "bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-400"
                : "bg-red-600 text-white border-red-600 shadow-md ring-2 ring-red-400"
              : userChoice !== null && question.answer === "CERTO"
              ? "bg-emerald-100 text-emerald-900 border-emerald-400 dark:bg-emerald-950 dark:text-emerald-200"
              : "bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
          }`}
        >
          <CheckCircle2 className={`w-5 h-5 ${userChoice === "CERTO" ? "text-white" : "text-emerald-600 dark:text-emerald-400"}`} />
          <span>CERTO</span>
        </button>

        <button
          disabled={!interactive}
          onClick={() => handleSelect("ERRADO")}
          className={`py-3 px-4 rounded-xl font-bold text-sm md:text-base border transition-all flex items-center justify-center gap-2 ${
            userChoice === "ERRADO"
              ? question.answer === "ERRADO"
                ? "bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-400"
                : "bg-red-600 text-white border-red-600 shadow-md ring-2 ring-red-400"
              : userChoice !== null && question.answer === "ERRADO"
              ? "bg-emerald-100 text-emerald-900 border-emerald-400 dark:bg-emerald-950 dark:text-emerald-200"
              : "bg-white dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-red-950/40 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
          }`}
        >
          <XCircle className={`w-5 h-5 ${userChoice === "ERRADO" ? "text-white" : "text-red-600 dark:text-red-400"}`} />
          <span>ERRADO</span>
        </button>
      </div>

      {/* Answer feedback summary toggle */}
      {!showExplanation && userChoice === null && (
        <div className="flex justify-end">
          <button
            onClick={() => setShowExplanation(true)}
            className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold hover:underline flex items-center gap-1"
          >
            <Lightbulb className="w-3.5 h-3.5" /> Ver Gabarito e Explicação
          </button>
        </div>
      )}

      {/* Explanation Rationale Panel (Cebraspe Standard) */}
      {showExplanation && (
        <div className="mt-5 border-t border-slate-200 dark:border-slate-800 pt-5 space-y-4">
          {/* User Feedback Badge */}
          {userChoice && (
            <div className={`p-3 rounded-lg border flex items-center justify-between ${
              isCorrect
                ? "bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-200 dark:border-emerald-800"
                : "bg-red-50 text-red-900 border-red-200 dark:bg-red-950/60 dark:text-red-200 dark:border-red-800"
            }`}>
              <div className="flex items-center gap-2 font-bold text-sm">
                {isCorrect ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>VOCÊ ACERTOU! (+1 PONTO LÍQUIDO CEBRASPE)</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-red-600" />
                    <span>VOCÊ ERROU! (-1 PONTO LÍQUIDO CEBRASPE)</span>
                  </>
                )}
              </div>
              <span className="text-xs font-mono font-medium">Sua resposta: {userChoice}</span>
            </div>
          )}

          {/* Official Gabarito Header */}
          <div className="flex items-center justify-between bg-slate-900 text-white dark:bg-slate-800 p-3 rounded-lg">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wide text-slate-400 font-semibold">Gabarito Oficial CEBRASPE:</span>
              <span className={`px-3 py-0.5 rounded font-black text-sm ${
                question.answer === "CERTO" ? "bg-emerald-500 text-white" : "bg-red-500 text-white"
              }`}>
                {question.answer}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">{question.source}</span>
          </div>

          {/* Full Commentary */}
          <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5 mb-1">
                <Lightbulb className="w-4 h-4 text-amber-500" /> Comentário Detalhado:
              </h5>
              <p className="text-xs md:text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
                {question.explanation}
              </p>
            </div>

            {/* Trap Warning Box */}
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 p-3 rounded-lg">
              <h6 className="text-xs font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5 mb-1">
                <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" /> ONDE ESTÁ A PEGADINHA CEBRASPE:
              </h6>
              <p className="text-xs text-amber-900/90 dark:text-amber-200/90 leading-relaxed">
                {question.trap}
              </p>
            </div>

            {/* Correct Form Box */}
            <div className="bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 p-3 rounded-lg">
              <h6 className="text-xs font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5 mb-1">
                <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> COMO FICARIA CORRETO / AFIRMAÇÃO REEFETIVADA:
              </h6>
              <p className="text-xs text-emerald-900/90 dark:text-emerald-200/90 font-medium leading-relaxed italic">
                "{question.correctForm}"
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
