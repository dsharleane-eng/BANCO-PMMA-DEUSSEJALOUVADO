
import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  BookOpen,
  Timer,
  RotateCcw,
  Flame,
  Award,
  BarChart3,
  Database,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle,
  Clock
} from "lucide-react";

export type ModeType = "BANCO" | "SIMULADO" | "REVISAO" | "MARATONA" | "PMMA" | "ANALYTICS" | "MANAGER";

interface NavbarProps {
  activeMode: ModeType;
  onSelectMode: (mode: ModeType) => void;
  totalQuestionsCount: number;
}

export function Navbar({ activeMode, onSelectMode, totalQuestionsCount }: NavbarProps) {
  // Countdown to PMMA 2026 Exam: October 11, 2026
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; mins: number }>({ days: 0, hours: 0, mins: 0 });

  useEffect(() => {
    const targetDate = new Date("2026-10-11T08:00:00").getTime();

    const updateCountdown = () => {
      const now = new Date().getTime();
      const diff = targetDate - now;

      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        setTimeLeft({ days, hours, mins });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 60000);
    return () => clearInterval(interval);
  }, []);

  const modes = [
    { id: "BANCO" as ModeType, name: "Banco de Questões", icon: BookOpen, badge: "2.000" },
    { id: "SIMULADO" as ModeType, name: "Modo Simulado", icon: Timer, badge: "Treino" },
    { id: "REVISAO" as ModeType, name: "Modo Revisão", icon: RotateCcw, badge: "Erros" },
    { id: "MARATONA" as ModeType, name: "Modo Maratona", icon: Flame, badge: "Hardcore" },
    { id: "PMMA" as ModeType, name: "Prova PMMA 2026", icon: Award, badge: "120 Itens" },
    { id: "ANALYTICS" as ModeType, name: "Desempenho", icon: BarChart3, badge: "Radar" },
    { id: "MANAGER" as ModeType, name: "Gestor (2.000)", icon: Database, badge: "PostgreSQL" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900 text-white border-b border-slate-800 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header Bar */}
        <div className="py-3 flex flex-col md:flex-row items-center justify-between gap-3 border-b border-slate-800/80">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-950">
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-400 bg-clip-text text-transparent">
                  PMMA 2026 • SOLDADO QP/QPMus
                </h1>
                <span className="text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  CEBRASPE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                Plataforma Completa de 2.000 Questões Certo / Errado • Edital Retificado
              </p>
            </div>
          </div>

          {/* Right Status Badge & Exam Countdown */}
          <div className="flex items-center gap-3 flex-wrap">
            {/* Live Questions DB Badge */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/90 border border-slate-700 text-xs font-semibold">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>{totalQuestionsCount.toLocaleString("pt-BR")} Questões no Banco</span>
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 ml-0.5" />
            </div>

            {/* Exam Target Date Countdown */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-200">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-semibold">Prova: 11/10/2026</span>
              <span className="text-slate-400">•</span>
              <span className="font-mono text-emerald-300">
                {timeLeft.days}d {timeLeft.hours}h até a prova
              </span>
            </div>
          </div>
        </div>

        {/* Mode Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-none">
          {modes.map((mode) => {
            const Icon = mode.icon;
            const isActive = activeMode === mode.id;

            return (
              <button
                key={mode.id}
                onClick={() => onSelectMode(mode.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? "bg-emerald-600 text-white shadow-md shadow-emerald-950/50"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/70"
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400"}`} />
                <span>{mode.name}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                    isActive
                      ? "bg-emerald-700 text-emerald-100"
                      : "bg-slate-800 text-slate-400 border border-slate-700"
                  }`}
                >
                  {mode.badge}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
