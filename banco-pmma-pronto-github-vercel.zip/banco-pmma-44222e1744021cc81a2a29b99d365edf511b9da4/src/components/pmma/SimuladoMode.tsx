
import React, { useState, useEffect } from "react";
import { QuestionCard, QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";
import {
  Timer,
  Play,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Award,
  RotateCcw,
  Clock,
  ListOrdered,
  ChevronLeft,
  ChevronRight,
  Send,
  Flag,
  Sparkles
} from "lucide-react";

export function SimuladoMode() {
  const [config, setConfig] = useState({
    totalItems: 30,
    discipline: "Todas",
    timeMinutes: 45,
    enablePenalty: true, // Cebraspe 1 wrong cancels 1 right
  });

  const [isRunning, setIsRunning] = useState(false);
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, "CERTO" | "ERRADO" | null>>({});
  const [flaggedItems, setFlaggedItems] = useState<Set<number>>(new Set());
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<any>(null);

  // Timer countdown
  useEffect(() => {
    if (!isRunning || isSubmitted || timeLeftSeconds <= 0) return;

    const timer = setInterval(() => {
      setTimeLeftSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, isSubmitted, timeLeftSeconds]);

  const handleStartSimulado = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (config.discipline !== "Todas") params.set("discipline", config.discipline);
      params.set("limit", config.totalItems.toString());
      params.set("random", "true");
      params.set("mode", "SIMULADO");

      const res = await apiFetch(`/api/questions?${params.toString()}`);
      const data = await res.json();

      if (res.ok && data.questions && data.questions.length > 0) {
        setQuestions(data.questions);
        setUserAnswers({});
        setFlaggedItems(new Set());
        setCurrentIndex(0);
        setTimeLeftSeconds(config.timeMinutes * 60);
        setIsSubmitted(false);
        setIsRunning(true);
      }
    } catch (err) {
      console.error("Error starting simulado:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (qNum: number, choice: "CERTO" | "ERRADO") => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qNum]: choice }));
  };

  const toggleFlag = (qNum: number) => {
    setFlaggedItems((prev) => {
      const next = new Set(prev);
      if (next.has(qNum)) next.delete(qNum);
      else next.add(qNum);
      return next;
    });
  };

  const handleSubmitExam = async () => {
    setIsSubmitted(true);
    setIsRunning(false);

    let correctCount = 0;
    let incorrectCount = 0;
    let blankCount = 0;

    questions.forEach((q) => {
      const ans = userAnswers[q.questionNumber];
      if (!ans) {
        blankCount++;
      } else if (ans === q.answer) {
        correctCount++;
      } else {
        incorrectCount++;
      }
    });

    const netScore = config.enablePenalty ? correctCount - incorrectCount : correctCount;
    const percentage = questions.length > 0 ? (correctCount / questions.length) * 100 : 0;
    const timeSpent = config.timeMinutes * 60 - timeLeftSeconds;

    const summaryData = {
      total: questions.length,
      correctCount,
      incorrectCount,
      blankCount,
      netScore,
      percentage: Number(percentage.toFixed(1)),
      timeSpentSeconds: timeSpent
    };

    setSummary(summaryData);

    // Save exam session to PostgreSQL
    try {
      await apiFetch("/api/exam-sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "SIMULADO",
          title: `Simulado Customizado (${config.totalItems} itens)`,
          totalQuestions: questions.length,
          correctCount,
          incorrectCount,
          blankCount,
          netScore,
          percentage: summaryData.percentage,
          timeSpentSeconds: timeSpent
        })
      });

      // Save individual question responses
      for (const q of questions) {
        const ans = userAnswers[q.questionNumber];
        if (ans) {
          await apiFetch("/api/responses", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              questionId: q.questionNumber,
              userAnswer: ans,
              mode: "SIMULADO"
            })
          });
        }
      }
    } catch (err) {
      console.error("Error saving exam session:", err);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // 1. Config Setup Screen
  if (!isRunning && !isSubmitted) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 border border-slate-800 shadow-sm text-center md:text-left">
          <div className="flex items-center gap-2 mb-2 justify-center md:justify-start">
            <Timer className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-extrabold tracking-tight">Simulado Personalizado CEBRASPE</h2>
          </div>
          <p className="text-xs md:text-sm text-slate-300 leading-relaxed max-w-xl">
            Configure seu treino sob medida com tempo cronometrado e cálculo exato da pontuação líquida da CEBRASPE (<span className="text-emerald-400 font-bold">1 errada anula 1 certa</span>).
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800 pb-2">
            Parâmetros do Simulado
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Quantidade de Questões:
              </label>
              <select
                value={config.totalItems}
                onChange={(e) => setConfig({ ...config, totalItems: parseInt(e.target.value, 10) })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-3 font-semibold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
              >
                <option value={15}>15 Questões (Rápido)</option>
                <option value={30}>30 Questões (Médio)</option>
                <option value={60}>60 Questões (Meia Prova)</option>
                <option value={120}>120 Questões (Simulado Completo CEBRASPE)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Disciplina Alvo:
              </label>
              <select
                value={config.discipline}
                onChange={(e) => setConfig({ ...config, discipline: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-3 font-semibold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Todas">Todas as Disciplinas do Edital</option>
                <option value="Língua Portuguesa">Língua Portuguesa</option>
                <option value="História do Maranhão">História do Maranhão</option>
                <option value="Geografia do Maranhão">Geografia do Maranhão</option>
                <option value="Raciocínio Lógico">Raciocínio Lógico</option>
                <option value="História do Brasil">História do Brasil</option>
                <option value="Geografia do Brasil">Geografia do Brasil</option>
                <option value="Legislação PMMA (Estatuto)">Legislação PMMA (Estatuto)</option>
                <option value="Informática">Informática</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tempo Limite (Minutos):
              </label>
              <select
                value={config.timeMinutes}
                onChange={(e) => setConfig({ ...config, timeMinutes: parseInt(e.target.value, 10) })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs p-3 font-semibold text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500"
              >
                <option value={20}>20 Minutos</option>
                <option value={45}>45 Minutos</option>
                <option value={90}>90 Minutos (1h30)</option>
                <option value={210}>210 Minutos (3h30 - Prova Real)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Regra de Pontuação CEBRASPE:
              </label>
              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800 dark:text-slate-200">
                  <input
                    type="checkbox"
                    checked={config.enablePenalty}
                    onChange={(e) => setConfig({ ...config, enablePenalty: e.target.checked })}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  Penalizar erros (1 errada anula 1 certa)
                </label>
              </div>
            </div>
          </div>

          <button
            disabled={loading}
            onClick={handleStartSimulado}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>Iniciando Simulado...</span>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" />
                <span>INICIAR SIMULADO AGORA</span>
              </>
            )}
          </button>
        </div>
      </div>
    );
  }

  // 2. Active Exam Simulation Interface
  if (isRunning && !isSubmitted && questions.length > 0) {
    const currentQ = questions[currentIndex]!;
    const answeredCount = Object.keys(userAnswers).length;

    return (
      <div className="space-y-6">
        {/* Exam Running Sticky Header */}
        <div className="sticky top-16 z-40 bg-slate-900 text-white p-4 rounded-xl shadow-lg border border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold px-3 py-1 bg-emerald-600 rounded-md">
              Item {currentIndex + 1} de {questions.length}
            </span>
            <span className="text-xs text-slate-300 font-medium hidden sm:inline">
              Respondidas: <strong className="text-emerald-400">{answeredCount}</strong> / {questions.length}
            </span>
          </div>

          {/* Countdown Clock */}
          <div className="flex items-center gap-2 font-mono text-base font-extrabold bg-slate-800 px-3.5 py-1.5 rounded-lg border border-slate-700 text-amber-400">
            <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>{formatTime(timeLeftSeconds)}</span>
          </div>

          <button
            onClick={() => {
              if (confirm("Tem certeza que deseja finalizar e entregar seu simulado agora?")) {
                handleSubmitExam();
              }
            }}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" /> Finalizar e Entregar
          </button>
        </div>

        {/* Question Bubble Grid Navigator */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-semibold text-slate-500 mb-2 flex items-center justify-between">
            <span>Gabarito de Respostas Rápido:</span>
            <span className="text-[10px]">Verde = Respondida • Amarelo = Marcada</span>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1">
            {questions.map((q, idx) => {
              const isAns = userAnswers[q.questionNumber] !== undefined && userAnswers[q.questionNumber] !== null;
              const isFlag = flaggedItems.has(q.questionNumber);
              const isCurrent = idx === currentIndex;

              return (
                <button
                  key={q.questionNumber}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-7 h-7 rounded text-xs font-mono font-bold transition-all ${
                    isCurrent
                      ? "ring-2 ring-emerald-500 ring-offset-1 bg-slate-900 text-white"
                      : isAns
                      ? "bg-emerald-600 text-white"
                      : isFlag
                      ? "bg-amber-400 text-amber-950"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Question Item Box */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <span className="text-xs font-bold px-2.5 py-1 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 rounded border border-emerald-200">
              {currentQ.discipline} • {currentQ.difficulty}
            </span>

            <button
              onClick={() => toggleFlag(currentQ.questionNumber)}
              className={`text-xs font-semibold px-3 py-1 rounded-lg border flex items-center gap-1 transition-colors ${
                flaggedItems.has(currentQ.questionNumber)
                  ? "bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-300"
                  : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-400"
              }`}
            >
              <Flag className="w-3.5 h-3.5" />
              <span>{flaggedItems.has(currentQ.questionNumber) ? "Marcada para Dúvida" : "Marcar para Revisar"}</span>
            </button>
          </div>

          <div className="text-xs text-slate-500">
            <strong>Assunto:</strong> {currentQ.topic} ({currentQ.subtopic})
          </div>

          {currentQ.textContext && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs leading-relaxed font-serif border border-slate-200 dark:border-slate-800">
              {currentQ.textContext}
            </div>
          )}

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-sm font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
            {currentQ.statement}
          </div>

          {/* Interactive CERTO / ERRADO selection for Simulado */}
          <div className="grid grid-cols-2 gap-4 pt-2">
            <button
              onClick={() => handleAnswerChange(currentQ.questionNumber, "CERTO")}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm border transition-all flex items-center justify-center gap-2 ${
                userAnswers[currentQ.questionNumber] === "CERTO"
                  ? "bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-400"
                  : "bg-white dark:bg-slate-800 hover:bg-emerald-50 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>CERTO</span>
            </button>

            <button
              onClick={() => handleAnswerChange(currentQ.questionNumber, "ERRADO")}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm border transition-all flex items-center justify-center gap-2 ${
                userAnswers[currentQ.questionNumber] === "ERRADO"
                  ? "bg-red-600 text-white border-red-600 shadow-md ring-2 ring-red-400"
                  : "bg-white dark:bg-slate-800 hover:bg-red-50 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
              }`}
            >
              <XCircle className="w-5 h-5" />
              <span>ERRADO</span>
            </button>
          </div>

          {/* Nav Prev / Next Controls */}
          <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-4 mt-4">
            <button
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(currentIndex - 1)}
              className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold disabled:opacity-40 flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" /> Item Anterior
            </button>

            <button
              disabled={currentIndex === questions.length - 1}
              onClick={() => setCurrentIndex(currentIndex + 1)}
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 disabled:opacity-40 flex items-center gap-1"
            >
              Próximo Item <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Post-Exam Result Summary
  if (isSubmitted && summary) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Score Hero Card */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white p-8 rounded-2xl border border-slate-800 shadow-xl text-center space-y-4">
          <Award className="w-12 h-12 text-emerald-400 mx-auto" />
          <h2 className="text-2xl font-extrabold tracking-tight">Resultado do Simulado CEBRASPE</h2>
          <p className="text-xs text-slate-300">PMMA 2026 • Análise do Desempenho e Pontuação Líquida</p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-2xl font-black text-emerald-400">{summary.netScore}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Pontos Líquidos</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-2xl font-black text-white">{summary.percentage}%</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Aproveitamento</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-2xl font-black text-emerald-400">{summary.correctCount}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Acertos (+1)</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-2xl font-black text-red-400">{summary.incorrectCount}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Erros (-1)</span>
            </div>
          </div>

          <button
            onClick={() => {
              setIsSubmitted(false);
              setIsRunning(false);
            }}
            className="mt-4 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-2 mx-auto"
          >
            <RotateCcw className="w-4 h-4" /> Novo Simulado
          </button>
        </div>

        {/* Detailed Questions Review List */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <ListOrdered className="w-5 h-5 text-emerald-600" />
            <span>Revisão Item por Item do Simulado ({questions.length} questões)</span>
          </h3>

          {questions.map((q) => (
            <QuestionCard
              key={q.questionNumber}
              question={q}
              userAnswer={userAnswers[q.questionNumber] || null}
              showExplanationInitially={true}
              interactive={false}
            />
          ))}
        </div>
      </div>
    );
  }

  return null;
}
