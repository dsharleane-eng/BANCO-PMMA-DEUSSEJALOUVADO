
import React, { useState, useEffect } from "react";
import { QuestionCard, QuestionType } from "./QuestionCard";
import { apiFetch } from "@/lib/apiFetch";
import {
  Award,
  ShieldCheck,
  Clock,
  Play,
  Send,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Flag,
  FileText,
  ChevronLeft,
  ChevronRight,
  ListOrdered
} from "lucide-react";

export function PmmaExamMode() {
  const [isRunning, setIsRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuestionType[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, "CERTO" | "ERRADO" | null>>({});
  const [flaggedItems, setFlaggedItems] = useState<Set<number>>(new Set());
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(210 * 60); // 3h30m = 210 mins
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [summary, setSummary] = useState<any>(null);

  useEffect(() => {
    if (!isRunning || isSubmitted || timeLeftSeconds <= 0) return;

    const timer = setInterval(() => {
      setTimeLeftSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitOfficialExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, isSubmitted, timeLeftSeconds]);

  const handleStartOfficialExam = async () => {
    setLoading(true);
    try {
      // Fetch proportionate questions according to official Edital distribution
      const distributions = [
        { discipline: "Língua Portuguesa", count: 27 },
        { discipline: "História do Maranhão", count: 24 },
        { discipline: "Geografia do Maranhão", count: 24 },
        { discipline: "Raciocínio Lógico", count: 18 },
        { discipline: "História do Brasil", count: 13 },
        { discipline: "Geografia do Brasil", count: 14 },
      ];

      let loadedQuestions: QuestionType[] = [];

      for (const dist of distributions) {
        const params = new URLSearchParams();
        params.set("discipline", dist.discipline);
        params.set("limit", dist.count.toString());
        params.set("random", "true");
        params.set("mode", "PMMA");

        const res = await apiFetch(`/api/questions?${params.toString()}`);
        const data = await res.json();

        if (res.ok && data.questions) {
          loadedQuestions = [...loadedQuestions, ...data.questions];
        }
      }

      setQuestions(loadedQuestions);
      setUserAnswers({});
      setFlaggedItems(new Set());
      setCurrentIndex(0);
      setTimeLeftSeconds(210 * 60); // 3 hours 30 mins
      setIsSubmitted(false);
      setIsRunning(true);
    } catch (err) {
      console.error("Error starting PMMA official exam:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (qNum: number, choice: "CERTO" | "ERRADO") => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [qNum]: choice }));
  };

  const toggleFlag = (qNum: number) => {
    setFlaggedItems((prev) => {
      const next = new Set(prev);
      if (next.has(qNum)) next.delete(qNum);
      else next.add(qNum);
      return next;
    });
  };

  const handleSubmitOfficialExam = async () => {
    setIsSubmitted(true);
    setIsRunning(false);

    let correctCount = 0;
    let incorrectCount = 0;
    let blankCount = 0;

    questions.forEach((q) => {
      const ans = userAnswers[q.questionNumber];
      if (!ans) {
        blankCount++;
      } else if (ans === q.answer) {
        correctCount++;
      } else {
        incorrectCount++;
      }
    });

    const netScore = correctCount - incorrectCount; // Cebraspe rule: 1 wrong cancels 1 correct
    const percentage = questions.length > 0 ? (correctCount / questions.length) * 100 : 0;
    const timeSpent = 210 * 60 - timeLeftSeconds;

    const summaryData = {
      total: questions.length,
      correctCount,
      incorrectCount,
      blankCount,
      netScore,
      percentage: Number(percentage.toFixed(1)),
      timeSpentSeconds: timeSpent
    };

    setSummary(summaryData);

    // Save session to PostgreSQL
    try {
      await apiFetch("/api/exam-sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "PMMA",
          title: "PROVA PMMA 2026 - SOLDADO QP/QPMus (120 Itens)",
          totalQuestions: questions.length,
          correctCount,
          incorrectCount,
          blankCount,
          netScore,
          percentage: summaryData.percentage,
          timeSpentSeconds: timeSpent
        })
      });

      for (const q of questions) {
        const ans = userAnswers[q.questionNumber];
        if (ans) {
          await apiFetch("/api/responses", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              questionId: q.questionNumber,
              userAnswer: ans,
              mode: "PMMA"
            })
          });
        }
      }
    } catch (err) {
      console.error("Error saving PMMA exam session:", err);
    }
  };

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h}h ${m.toString().padStart(2, "0")}m ${s.toString().padStart(2, "0")}s`;
  };

  if (!isRunning && !isSubmitted) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 text-white rounded-2xl p-8 border border-emerald-900 shadow-lg text-center space-y-4">
          <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto" />
          <h2 className="text-2xl font-extrabold tracking-tight">Simulação Oficial da Prova PMMA 2026</h2>
          <p className="text-xs md:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
            Esta modalidade recria com exatidão matemática a estrutura da Prova Objetiva de Soldado QP/QPMus do Maranhão: <span className="text-emerald-400 font-bold">120 Itens Certo/Errado em 3h30m</span> com distribuição por disciplina prevista no edital.
          </p>

          {/* Distribution Badge Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-left pt-2">
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">27 Itens</span>
              <span className="text-slate-300">Língua Portuguesa</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">24 Itens</span>
              <span className="text-slate-300">História do Maranhão</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">24 Itens</span>
              <span className="text-slate-300">Geografia do Maranhão</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">18 Itens</span>
              <span className="text-slate-300">Raciocínio Lógico</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">13 Itens</span>
              <span className="text-slate-300">História do Brasil</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-xs">
              <span className="text-emerald-400 font-bold block text-base">14 Itens</span>
              <span className="text-slate-300">Geografia do Brasil</span>
            </div>
          </div>

          <button
            disabled={loading}
            onClick={handleStartOfficialExam}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-4"
          >
            {loading ? (
              <span>Gerando Caderno de Prova de 120 Itens...</span>
            ) : (
              <>
                <Play className="w-5 h-5 fill-white" />
                <span>INICIAR SIMULADO OFICIAL PMMA (120 ITENS)</span>
              </>
            )}
          </button>
        </div>
      </div>
    );
  }

  // Active Exam
  if (isRunning && !isSubmitted && questions.length > 0) {
    const currentQ = questions[currentIndex]!;
    const answeredCount = Object.keys(userAnswers).length;

    return (
      <div className="space-y-6">
        {/* Sticky Exam Header */}
        <div className="sticky top-16 z-40 bg-slate-900 text-white p-4 rounded-xl shadow-lg border border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold px-3 py-1 bg-emerald-600 rounded-md">
              Item {currentIndex + 1} de {questions.length}
            </span>
            <span className="text-xs text-slate-300 font-medium hidden sm:inline">
              Preenchidos: <strong className="text-emerald-400">{answeredCount}</strong> / 120
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-base font-extrabold bg-slate-800 px-3.5 py-1.5 rounded-lg border border-slate-700 text-emerald-300">
            <Clock className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>{formatTime(timeLeftSeconds)}</span>
          </div>

          <button
            onClick={() => {
              if (confirm("Deseja encerrar o caderno de provas e enviar a folha de respostas?")) {
                handleSubmitOfficialExam();
              }
            }}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" /> Entregar Prova
          </button>
        </div>

        {/* Digital Answer Sheet Grid (Cartão Resposta) */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="text-xs font-semibold text-slate-500 mb-2 flex items-center justify-between">
            <span>Cartão-Resposta Digital CEBRASPE (120 Itens):</span>
            <span className="text-[10px]">Verde = Preenchido • Clique para ir ao item</span>
          </div>
          <div className="grid grid-cols-10 sm:grid-cols-12 md:grid-cols-20 gap-1.5 max-h-32 overflow-y-auto p-1">
            {questions.map((q, idx) => {
              const isAns = userAnswers[q.questionNumber] !== undefined && userAnswers[q.questionNumber] !== null;
              const isCurrent = idx === currentIndex;

              return (
                <button
                  key={q.questionNumber}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-6 h-6 rounded text-[10px] font-mono font-bold transition-all ${
                    isCurrent
                      ? "ring-2 ring-emerald-500 bg-slate-900 text-white"
                      : isAns
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Question View Box */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <span className="text-xs font-bold px-2.5 py-1 bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded border border-emerald-200">
              {currentQ.discipline}
            </span>
            <span className="text-xs text-slate-400 font-mono">PROVA PMMA 2026</span>
          </div>

          <div className="text-xs text-slate-500">
            <strong>Assunto:</strong> {currentQ.topic} ({currentQ.subtopic})
          </div>

          {currentQ.textContext && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs leading-relaxed font-serif border border-slate-200 dark:border-slate-800">
              {currentQ.textContext}
            </div>
          )}

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-sm font-medium text-slate-900 dark:text-slate-100 leading-relaxed">
            {currentQ.statement}
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <button
              onClick={() => handleAnswerChange(currentQ.questionNumber, "CERTO")}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm border transition-all flex items-center justify-center gap-2 ${
                userAnswers[currentQ.questionNumber] === "CERTO"
                  ? "bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-400"
                  : "bg-white dark:bg-slate-800 hover:bg-emerald-50 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>CERTO</span>
            </button>

            <button
              onClick={() => handleAnswerChange(currentQ.questionNumber, "ERRADO")}
              className={`py-3.5 px-4 rounded-xl font-bold text-sm border transition-all flex items-center justify-center gap-2 ${
                userAnswers[currentQ.questionNumber] === "ERRADO"
                  ? "bg-red-600 text-white border-red-600 shadow-md ring-2 ring-red-400"
                  : "bg-white dark:bg-slate-800 hover:bg-red-50 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-700"
              }`}
            >
              <XCircle className="w-5 h-5" />
              <span>ERRADO</span>
            </button>
          </div>

          <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-4 mt-4">
            <button
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(currentIndex - 1)}
              className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold disabled:opacity-40 flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" /> Item Anterior
            </button>

            <button
              disabled={currentIndex === questions.length - 1}
              onClick={() => setCurrentIndex(currentIndex + 1)}
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 disabled:opacity-40 flex items-center gap-1"
            >
              Próximo Item <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Summary Report
  if (isSubmitted && summary) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-900 text-white p-8 rounded-2xl border border-emerald-900 shadow-xl text-center space-y-4">
          <Award className="w-12 h-12 text-emerald-400 mx-auto" />
          <h2 className="text-2xl font-extrabold tracking-tight">Resultado do Simulado PMMA 2026 (120 Itens)</h2>
          <p className="text-xs text-slate-300">Cálculo no padrão oficial CEBRASPE (1 incorreta anula 1 correta)</p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-3xl font-black text-emerald-400">{summary.netScore}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Nota Líquida (/120)</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-3xl font-black text-white">{summary.percentage}%</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Aproveitamento</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-3xl font-black text-emerald-400">{summary.correctCount}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Acertos</span>
            </div>

            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700">
              <span className="block text-3xl font-black text-red-400">{summary.incorrectCount}</span>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">Erros</span>
            </div>
          </div>

          <button
            onClick={() => {
              setIsSubmitted(false);
              setIsRunning(false);
            }}
            className="mt-4 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all flex items-center gap-2 mx-auto"
          >
            <RotateCcw className="w-4 h-4" /> Novo Simulado PMMA
          </button>
        </div>

        {/* Detailed Review */}
        <div className="space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <ListOrdered className="w-5 h-5 text-emerald-600" />
            <span>Revisão Completa do Caderno de Prova (120 Itens)</span>
          </h3>

          {questions.map((q) => (
            <QuestionCard
              key={q.questionNumber}
              question={q}
              userAnswer={userAnswers[q.questionNumber] || null}
              showExplanationInitially={true}
              interactive={false}
            />
          ))}
        </div>
      </div>
    );
  }

  return null;
}
