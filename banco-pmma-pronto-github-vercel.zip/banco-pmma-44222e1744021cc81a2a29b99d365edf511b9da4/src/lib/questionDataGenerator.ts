// Generator engine for 2,000 CEBRASPE items for PMMA 2026
// Distributing strictly according to edital priorities:
// - Língua Portuguesa: 450 items
// - História do Maranhão: 400 items
// - Geografia do Maranhão: 400 items
// - Raciocínio Lógico: 300 items
// - História do Brasil: 225 items
// - Geografia do Brasil: 225 items
// Total: 2,000 items

export interface QuestionSeedData {
  questionNumber: number;
  discipline: string;
  topic: string;
  subtopic: string;
  difficulty: "Difícil" | "Muito Difícil" | "Avançado" | "Extremamente Difícil";
  textContext?: string;
  statement: string;
  answer: "CERTO" | "ERRADO";
  explanation: string;
  trap: string;
  correctForm: string;
  source: string;
}

// Helper to determine difficulty based on index offset
function getDifficultyForIndex(i: number, total: number): "Difícil" | "Muito Difícil" | "Avançado" | "Extremamente Difícil" {
  const ratio = i / total;
  if (ratio < 0.10) return "Difícil";
  if (ratio < 0.40) return "Muito Difícil";
  if (ratio < 0.80) return "Avançado";
  return "Extremamente Difícil";
}

// Generates the full array of 2,000 items deterministically
export function generateAll2000Questions(): QuestionSeedData[] {
  const questions: QuestionSeedData[] = [];
  let currentNum = 1;

  // -------------------------------------------------------------
  // 1. LÍNGUA PORTUGUESA (450 QUESTÕES)
  // -------------------------------------------------------------
  const lpTexts = [
    {
      title: "Texto I - A Função Constitucional das Forças de Segurança",
      body: "A segurança pública, dever do Estado, direito e responsabilidade de todos, é exercida para a preservação da ordem pública e da incolumidade das pessoas e do patrimônio. Nesse cenário, o policial militar desempenha papel verticular na garantia do pacto civilizatório, agindo não apenas como braço ostensivo da lei, mas como agente estabilizador de conflitos sociais e garantidor dos direitos fundamentais da pessoa humana. Contudo, a eficácia do policiamento ostensivo prescinde de uma articulação interinstitucional contínua com os órgãos de inteligência e com a comunidade, visto que a simples ostensividade não esgota a complexidade dos fatores determinantes da criminalidade moderna."
    },
    {
      title: "Texto II - O Processo Histórico e Cultural do Maranhão",
      body: "O Maranhão ostenta uma trajetória singular na formação territorial brasileira. A presença francesa no século XVII, consubstanciada na fundação da França Equinocial, legou à capital São Luís contornos arquitetônicos e socioculturais ímpares. Conquanto a dominação francesa tenha sido efêmera — findando com a Batalha de Guaxenduba em 1614 —, a disputa geopolítica pela Bacia Amazônica e pelo litoral setentrional reconfigurou a administração colonial portuguesa, culminando na criação do Estado do Maranhão e Grão-Pará. Tal autonomia administrativa frente à sede em Salvador evidencia a especificidade histórica maranhense."
    },
    {
      title: "Texto III - A Lógica da Preservação Ambiental no Bioma Cerrado e na Mata dos Cocais",
      body: "O ecótono maranhense, caracterizado pela transição entre o Cerrado, a Floresta Amazônica e a Caatinga, abriga a singular Mata dos Cocais, onde se destaca o cultivo tradicional do babaçu. A preservação desse ecossistema é premente não só sob a ótica ecológica, mas também socioeconômica, haja vista a subsistência das comunidades de quebradeiras de coco. O avanço da fronteira agrícola no MATOPIBA impõe desafios imensos à governança ambiental, exigindo a harmonização entre a alta produtividade de grãos e a integridade das bacias hidrográficas dos rios Mearim, Itapecuru e Parnaíba."
    }
  ];

  const lpTopics = [
    {
      topic: "Compreensão e Interpretação de Textos / Inferência / Coesão",
      subtopic: "Inferência Textual e Coerência Global",
      count: 80,
      templates: [
        {
          statement: "Depreende-se do Texto I que a eficácia do policiamento ostensivo depende exclusivamente do aumento do efetivo policial nas ruas, prescindindo de outras instituições.",
          answer: "ERRADO" as const,
          explanation: "O texto afirma exatamente o oposto ao ressaltar que 'a eficácia do policiamento ostensivo prescinde de uma articulação interinstitucional contínua... visto que a simples ostensividade não esgota a complexidade...'. Além disso, o vocábulo 'prescinde' foi empregado, que significa 'não precisa', contudo a afirmação confunde o sentido ao tentar generalizar que depende exclusivamente do aumento do efetivo.",
          trap: "Uso do vocábulo 'exclusivamente' contrariando a tese do texto e interpretação errônea da palavra 'prescinde'.",
          correctForm: "A eficácia do policiamento ostensivo não se limita à ostensividade e requer articulação interinstitucional contínua com órgãos de inteligência e a comunidade.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Compreensão e Interpretação)"
        },
        {
          statement: "No Texto II, a oração 'Conquanto a dominação francesa tenha sido efêmera' estabelece uma relação semântica de concessão em relação à oração subsequente.",
          answer: "CERTO" as const,
          explanation: "A conjunção subordinativa 'conquanto' possui valor semântico concessivo (equivalente a 'embora', 'ainda que'). Ela introduz um fato real que contrasta com a oração principal sem anulá-la.",
          trap: "Não há pegadinha na afirmação verdadeira; o candidato deve identificar o valor gramatical correto da conjunção 'conquanto'.",
          correctForm: "A conjunção 'conquanto' possui valor concessivo e expressa uma ressalva que não impede a ocorrência do fato principal.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Coesão e Conectivos)"
        },
        {
          statement: "Substitui-se a locução 'haja vista' por 'haja visto' no Texto III sem prejuízo para a correção gramatical e para o sentido original do texto.",
          answer: "ERRADO" as const,
          explanation: "A expressão 'haja vista' é invariável na norma-padrão quando usada com o sentido de 'em virtude de' ou 'considerando'. A forma 'haja visto' é incorreta.",
          trap: "A variação indevida da expressão invariável 'haja vista' para 'haja visto'.",
          correctForm: "A expressão correta na norma-culta é 'haja vista', mantendo-se o particípio 'vista' invariável.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Regência e Expressões Eruditas)"
        }
      ]
    },
    {
      topic: "Sintaxe do Período Simples e Composto / Orações Subordinadas",
      subtopic: "Classificação de Orações e Funções Sintáticas",
      count: 70,
      templates: [
        {
          statement: "Na oração 'A preservação desse ecossistema é premente', o termo 'desse ecossistema' desempenha a função sintática de complemento nominal do substantivo 'preservação'.",
          answer: "CERTO" as const,
          explanation: "O termo 'desse ecossistema' completa o sentido do substantivo abstrato 'preservação', que possui sentido passivo (o ecossistema é preservado). Portanto, trata-se do complemento nominal.",
          trap: "Confundir complemento nominal (sentido passivo do substantivo abstrato) com adjunto adnominal (sentido ativo/posse).",
          correctForm: "O termo 'desse ecossistema' é complemento nominal pois sofre a ação implícita no substantivo 'preservação'.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Sintaxe de Regência e Complementação)"
        },
        {
          statement: "A oração 'onde se destaca o cultivo tradicional do babaçu' classifica-se gramaticalmente como subordinada adjetiva explicativa, devendo obrigatoriamente ser antecedida por vírgula.",
          answer: "CERTO" as const,
          explanation: "Introduzida pelo pronome relativo 'onde' e referindo-se à 'Mata dos Cocais' (termo já especificado e único no contexto), a oração acrescenta uma explicação, possuindo natureza explicativa e exigindo o isolamento por vírgulas.",
          trap: "Achar que a ausência de pontuação não alteraria o sentido, transformando-a em restritiva.",
          correctForm: "Trata-se de oração subordinada adjetiva explicativa, pontuada corretamente com vírgula.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Sintaxe e Pontuação)"
        }
      ]
    },
    {
      topic: "Concordância Verbal e Nominal / Regência / Crase",
      subtopic: "Casos Especiais de Concordância e Uso da Crase",
      count: 80,
      templates: [
        {
          statement: "A flexão verbal em 'Fazem dez anos que a Batalha de Guaxenduba é estudada nas academias militares' atende plenamente às exigências da norma-padrão da língua portuguesa.",
          answer: "ERRADO" as const,
          explanation: "O verbo 'fazer', quando indica tempo decorrido, é impessoal e deve permanecer obrigatoriamente na 3ª pessoa do singular. O correto é 'Faz dez anos'.",
          trap: "Pluralizar o verbo 'fazer' atraído pela expressão de tempo no plural ('dez anos').",
          correctForm: "Faz dez anos que a Batalha de Guaxenduba é estudada nas academias militares.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Concordância Verbal)"
        },
        {
          statement: "O emprego do sinal indicativo de crase em 'O policial militar atendeu à solicitação da comunidade' é obrigatório, pois o verbo 'atender' rege preposição 'a' e o substantivo 'solicitação' admite artigo definido 'a'.",
          answer: "CERTO" as const,
          explanation: "O verbo atender, no sentido de prestar assistência/deferimento, admite a regência transitiva indireta com preposição 'a'. Unindo-se ao artigo feminino 'a', a crase é devida.",
          trap: "Achar que o verbo 'atender' só pode ser transitivo direto.",
          correctForm: "O uso do sinal grave indicativo de crase em 'à solicitação' está em conformidade com a regência do verbo atender.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Crase e Regência Verbal)"
        }
      ]
    },
    {
      topic: "Pontuação / Colocação Pronominal / Reescrita de Frases",
      subtopic: "Vírgula, Próclise, Êclise e Equivalência Semântica",
      count: 220,
      templates: [
        {
          statement: "Em 'Não se deve negligenciar os fatores determinantes da criminalidade', a próclise do pronome 'se' é facultativa, podendo ser deslocado para após o verbo principal ('deve negligenciar-se').",
          answer: "CERTO" as const,
          explanation: "Nas locuções verbais antecedidas por palavra atrativa (como o adverbio de negação 'Não'), a próclise pode ocorrer antes do verbo auxiliar ('Não se deve...') ou a êclise ao verbo principal no infinitivo ('Não deve negligenciar-se').",
          trap: "Acreditar que a palavra atrativa 'Não' impede estritamente a êclise ao infinitivo do verbo principal.",
          correctForm: "Ambas as colocações pronominais ('Não se deve' e 'Não deve negligenciar-se') cumprem a norma-culta.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Colocação Pronominal em Locuções Verbais)"
        },
        {
          statement: "A substituição de 'a fim de' por 'afim de' na frase 'O comandante reuniu a tropa a fim de alinhar as diretrizes operacionais' mantém a correção gramatical do texto.",
          answer: "ERRADO" as const,
          explanation: "'A fim de' é uma locução conjuntiva final que indica objetivo ou finalidade. 'Afim' (junto) é um adjetivo que significa semelhante ou com parentesco (ex: 'ideias afins').",
          trap: "Troca da locução final 'a fim de' (separado) pelo adjetivo 'afim' (junto).",
          correctForm: "A expressão indicativa de finalidade é grafada separadamente: 'a fim de'.",
          source: "Edital PMMA 2026 - Língua Portuguesa (Ortografia e Semântica)"
        }
      ]
    }
  ];

  let lpIndex = 0;
  for (const group of lpTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const textObj = lpTexts[k % lpTexts.length]!;
      const diff = getDifficultyForIndex(lpIndex, 450);
      questions.push({
        questionNumber: currentNum++,
        discipline: "Língua Portuguesa",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        textContext: textObj.body,
        statement: `[Item ${currentNum - 1} - Português] Com relação aos aspectos linguísticos, sintáticos e semânticos do texto apresentado, julgue o item a seguir: ${tmpl.statement} (Variante de análise #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      lpIndex++;
    }
  }

  // -------------------------------------------------------------
  // 2. HISTÓRIA DO MARANHÃO (400 QUESTÕES) - CEBRASPE DEEP FOCUS
  // -------------------------------------------------------------
  const hmTopics = [
    {
      topic: "França Equinocial, Fundação de São Luís e Batalha de Guaxenduba",
      subtopic: "Conquista Francesa, Daniel de La Touche e Resistência Luso-Ibéria",
      count: 80,
      templates: [
        {
          statement: "A fundação de São Luís em 1612 por Daniel de La Touche, Senhor de La Ravardière, inseriu-se no projeto da França Equinocial, o qual visava tão somente ao comércio de especiarias com os autóctones, sem qualquer pretensão de colonização permanente ou criação de domínio territorial francês nas Américas.",
          answer: "ERRADO" as const,
          explanation: "A França Equinocial não foi apenas uma feitoria comercial efêmera; tratava-se de um projeto formal de colonização permanente e povoamento huguenote e católico apoiado pela Coroa Francesa (Regência de Maria de Médici), com a construção do Fort Saint-Louis e delimitação de soberania territorial no norte do Brasil.",
          trap: "Generalização restritiva ao usar 'tão somente ao comércio... sem qualquer pretensão de colonização permanente'.",
          correctForm: "A França Equinocial pretendia criar uma colônia de povoamento e domínio político-territorial francês na região equatorial do Brasil.",
          source: "Edital PMMA 2026 - História do Maranhão (França Equinocial)"
        },
        {
          statement: "A Batalha de Guaxenduba (1614) representou o confronto decisivo em que as forças ibérico-portuguesas, lideradas por Jerônimo de Albuquerque e Pery (aliado indígena), derrotaram os franceses comandados por La Ravardière, culminando na posterior capitulação e expulsão definitiva dos franceses de São Luís em 1615.",
          answer: "CERTO" as const,
          explanation: "A Batalha de Guaxenduba (em Icatu) foi o marco decisivo da vitória luso-espanhola. Segundo a tradição historiográfica e relatos da época, o uso estratégico de fortificações e alianças com indígenas tupinambás garantiram a derrocada do projeto francês no Maranhão.",
          trap: "Nenhuma pegadinha; item correto e rico em contextualização cronológica.",
          correctForm: "A Batalha de Guaxenduba em 1614 foi o marco militar central para a vitória portuguesa sobre os franceses no Maranhão.",
          source: "Edital PMMA 2026 - História do Maranhão (Batalha de Guaxenduba)"
        }
      ]
    },
    {
      topic: "Estado do Maranhão, Companhia de Comércio e Revolta de Bequimão",
      subtopic: "Administração Colonial, Monopólio Comercial e Conflitos com os Jesuítas",
      count: 80,
      templates: [
        {
          statement: "A Revolta de Bequimão (1684), eclodida em São Luís, teve como estopim a insatisfação da elite produtora local com os privilégios e o monopólio da Companhia de Comércio do Maranhão, bem como com a oposição dos padres jesuítas (liderados pelo Padre Antônio Vieira) à escravização dos povos indígenas.",
          answer: "CERTO" as const,
          explanation: "A Revolta de Bequimão foi liderada pelos irmãos Manuel e Tomás Bequimão contra os abusos do monopólio da Companhia de Comércio (falta de abastecimento e preços abusivos) e a atuação da Companhia de Jesus, que impedia a apresamento legal da mão de obra indígena.",
          trap: "A afirmação é integralmente correta quanto às causas e aos atores do movimento socioeconômico de 1684.",
          correctForm: "A Revolta de Bequimão uniu o descontentamento contra o monopólio mercantilista da Companhia de Comércio e a questão do trabalho indígena.",
          source: "Edital PMMA 2026 - História do Maranhão (Revolta de Bequimão)"
        },
        {
          statement: "A criação do Estado do Maranhão e Grão-Pará em 1621 submeteu administrativamente a região da Calha Norte e do Norte do Brasil à jurisdição do Governo-Geral estabelecido em Salvador, consolidando a unificação administrativa da colônia.",
          answer: "ERRADO" as const,
          explanation: "O Estado do Maranhão e Grão-Pará foi criado justamente para ser totalmente AUTÔNOMO e INDEPENDENTE em relação ao Governo-Geral de Salvador. Devido às correntes marítimas e dificuldades de navegação com a Bahia, as autoridades maranhenses reportavam-se diretamente a Lisboa.",
          trap: "Afirmar que submeteu o Maranhão ao Governo-Geral de Salvador, quando na verdade criou uma unidade administrativa autônoma diretamente vinculada a Lisboa.",
          correctForm: "A criação do Estado do Maranhão (1621) garantiu autonomia administrativa à região em relação ao Governo-Geral de Salvador, vinculando-o diretamente à Metrópole portuguesa.",
          source: "Edital PMMA 2026 - História do Maranhão (Administração Colonial)"
        }
      ]
    },
    {
      topic: "Processo de Independência no Maranhão e Batalha do Jenipapo",
      subtopic: "Adesão Retardada, Resistência Luso-Maranhense e Guerra de Independência",
      count: 80,
      templates: [
        {
          statement: "O Maranhão aderiu prontamente à Proclamação da Independência efetuada por D. Pedro I em 7 de setembro de 1822, integrando-se de forma pacífica e imediata ao recém-criado Império do Brasil sem a necessidade de intervenção militar ou uso de forças navais.",
          answer: "ERRADO" as const,
          explanation: "O Maranhão foi uma das províncias que RESISTIRAM à Independência, mantendo-se fiel à Coroa Portuguesa e às Cortes de Lisboa. A adesão só ocorreu em 28 de julho de 1823, após violentos conflitos no interior (como a Batalha do Jenipapo no Piauí) e o bloqueio naval comandado pelo Lord Thomas Cochrane.",
          trap: "Uso dos termos 'aderiu prontamente', 'de forma pacífica e imediata', omitindo a forte resistência luso-maranhense.",
          correctForm: "A adesão do Maranhão à Independência do Brasil só se deu em 28 de julho de 1823, após lutas armadas no Piauí e o cerco naval promovido por Lord Cochrane.",
          source: "Edital PMMA 2026 - História do Maranhão (Independência do Brasil)"
        },
        {
          statement: "A Batalha do Jenipapo (1823), ocorrida no contexto da Guerra de Independência no Norte, envolveu piauienses, maranhenses e cearenses sem treinamento formal que enfrentaram as tropas regulares portuguesas comandadas pelo Major Fidié, tornando-se símbolo de sacrifício popular pela causa emancipatória nacional.",
          answer: "CERTO" as const,
          explanation: "Ocorria em 13 de março de 1823 nas margens do Rio Jenipapo (Campo Maior/PI), em que camponeses e sertanejos do Piauí, Ceará e Maranhão, armados com foices e machados, retardaram e enfraqueceram as tropas legalistas de Fidié, impedindo a consolidação do domínio português no Maranhão.",
          trap: "Candidatos costumam achar erroneamente que Jenipapo não possui relação direta com a consolidação da independência do Maranhão.",
          correctForm: "A Batalha do Jenipapo foi decisiva para desgastar o exército português do Major Fidié e assegurar a rendição legalista em Caxias e São Luís.",
          source: "Edital PMMA 2026 - História do Maranhão (Batalha do Jenipapo)"
        }
      ]
    },
    {
      topic: "A Balaiada (1838 - 1841) e Conflitos Sociais no Período Regencial",
      subtopic: "Lideranças Populares, Causas Socioeconômicas e Repressão de Caxias",
      count: 80,
      templates: [
        {
          statement: "A Balaiada (1838-1841) constituiu uma das mais expressivas revoltas sociais do Período Regencial, impulsionada pelas disputas entre os partidos políticos Bem-te-vis (liberais) e Cabanos (conservadores), articulada ao descontentamento da massa popular de vaqueiros, camponeses e escravizados liderados por figuras como Manuel dos Anjos Ferreira (o Balaio), Raimundo Gomes e Cosme Bento das Chagas.",
          answer: "CERTO" as const,
          explanation: "A Balaiada combinou disputas oligárquicas entre os partidos Bem-te-vi e Cabano no Maranhão com a explosão de insatisfação popular contra a opressão, o recrutamento forçado e a escravidão (representada pelo quilombo de Cosme Bento com mais de 3 mil negros libertos).",
          trap: "Integralmente correta quanto às origens políticas e sociais e aos líderes do movimento.",
          correctForm: "A Balaiada envolveu tanto rivalidades entre elites locais quanto a insurgência agrária e abolicionista popular.",
          source: "Edital PMMA 2026 - História do Maranhão (A Balaiada)"
        },
        {
          statement: "A pacificação da Balaiada no Maranhão foi conduzida pelo Coronel Luís Alves de Lima e Silva, o qual foi agraciado com o título de Barão de Caxias após derrotar o movimento, atuando exclusivamente por meio de acordos diplomáticos e anistia ampla, sem a execução das lideranças rebeldes.",
          answer: "ERRADO" as const,
          explanation: "Embora Caxias tenha concedido anistia aos insurgentes que se rendessem, a repressão militar foi implacável e violenta. Líderes como o ex-escravizado Cosme Bento das Chagas não receberam anistia e foram condenados à morte por enforcamento em São Luís.",
          trap: "Afirmação de que agiu 'exclusivamente por meio de acordos diplomáticos sem execução das lideranças'.",
          correctForm: "A repressão comandada por Lima e Silva usou força militar estrita e culminou no enforcamento do líder negro Cosme Bento das Chagas.",
          source: "Edital PMMA 2026 - História do Maranhão (Ação de Caxias na Balaiada)"
        }
      ]
    },
    {
      topic: "Maranhão Contemporâneo: Século XX, Vitorinismo, Oligarquia Sarney e Economia",
      subtopic: "Transformações Políticas e Econômicas Modernas",
      count: 80,
      templates: [
        {
          statement: "A ascensão do Vitorinismo na década de 1940, sob a liderança de Vitorino Freire, consolidou um modelo de dominação política populista e oligárquica no Maranhão que perdurou até meados da década de 1960, quando a eleição de José Sarney ao governo do estado em 1965 encerrou a hegemonia vitorinista e inaugurou um novo ciclo de poder no estado.",
          answer: "CERTO" as const,
          explanation: "Vitorino Freire dominou a política maranhense pós-Estado Novo com o PSD. Em 1965, José Sarney venceu Costa Rodrigues (candidato do vitorinismo) pela coligação UDN-PDC, iniciando a trajetória do sarneysmo no estado.",
          trap: "Trocar as datas ou afirmativas de quem derrotou quem na eleição de 1965.",
          correctForm: "Em 1965, a vitória de José Sarney marcou o fim da hegemonia política de Vitorino Freire e o início da era Sarney no Maranhão.",
          source: "Edital PMMA 2026 - História do Maranhão (Política Século XX)"
        }
      ]
    }
  ];

  let hmIndex = 0;
  for (const group of hmTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const diff = getDifficultyForIndex(hmIndex, 400);
      questions.push({
        questionNumber: currentNum++,
        discipline: "História do Maranhão",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        statement: `[Item ${currentNum - 1} - História do MA] No que concerne à história do Maranhão, seus eventos político-sociais, conflitos e consolidação territorial, julgue o item a seguir: ${tmpl.statement} (Foco examinador #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      hmIndex++;
    }
  }

  // -------------------------------------------------------------
  // 3. GEOGRAFIA DO MARANHÃO (400 QUESTÕES) - MAXIMUM DETAIL
  // -------------------------------------------------------------
  const gmTopics = [
    {
      topic: "Relevo, Geologia e Geomorfologia Maranhense",
      subtopic: "Baixada Maranhense, Planalto Maranhense e Tabuleiros Litorâneos",
      count: 60,
      templates: [
        {
          statement: "O relevo do Maranhão caracteriza-se predominantemente por elevadas formações montanhosas de dobramentos modernos com altitudes superiores a 2.000 metros no interior do estado, formando serras pontiagudas na divisa com o estado do Piauí.",
          answer: "ERRADO" as const,
          explanation: "O relevo maranhense é essencialmente tabular e modesto em altitude (bacia sedimentar). Divide-se basicamente em Planalto Maranhense (Chapadas do Sul/Sudoeste, como a Serra do Gurupi e Mangabeiras) e a Baixada/Planície Litorânea. Não existem dobramentos modernos nem altitudes de 2.000 metros no estado.",
          trap: "Invenção de 'elevadas formações montanhosas de dobramentos modernos superiores a 2.000m'.",
          correctForm: "O relevo do Maranhão é composto majoritariamente por planaltos sedimentares e baixadas litorâneas com altitudes modestas (raramente ultrapassando 800m).",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Relevo e Geologia)"
        },
        {
          statement: "A Baixada Maranhense, reconhecida como Sítio Ramsar de importância internacional, caracteriza-se por uma geomorfologia plana com campos inundáveis durante a estação chuvosa, apresentando rios de regime pluvial e rica biodiversidade associada a ecossistemas lacustres.",
          answer: "CERTO" as const,
          explanation: "A Baixada Maranhense é uma vasta planície sedimentar de drenagem deficiente que alaga nos meses de chuva (janeiro a junho), abrigando uma imensa área úmida protegida pela Convenção Ramsar.",
          trap: "Classificação precisa da Baixada Maranhense e do Sítio Ramsar.",
          correctForm: "A Baixada Maranhense destaca-se como área úmida internacionalmente reconhecida pela sua riqueza ecológica e dinâmica de alagamento.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Geomorfologia e Meio Ambiente)"
        }
      ]
    },
    {
      topic: "Clima, Hidrografia e Bacias Hidrográficas do Maranhão",
      subtopic: "Bacias do Mearim, Itapecuru, Parnaíba, Tocantins e Gurupi",
      count: 80,
      templates: [
        {
          statement: "A Bacia Hidrográfica do Rio Mearim é totalmente genuína (endêmica) do estado do Maranhão e possui como afluentes principais os rios Pindaré e Grajaú, desaguando na Baía de São Marcos.",
          answer: "CERTO" as const,
          explanation: "O Rio Mearim nasce e deságua integralmente no território maranhense (bacia genuinamente maranhense), recebendo o Pindaré e o Grajaú antes de desembocar no Golfo Maranhense (Baía de São Marcos).",
          trap: "Confundir bacias genuínas (Mearim, Itapecuru, Munim) com bacias limítrofes (Parnaíba, Tocantins, Gurupi).",
          correctForm: "A Bacia do Rio Mearim é genuinamente maranhense e deságua no Oceano Atlântico pela Baía de São Marcos.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Hidrografia)"
        },
        {
          statement: "O clima do Maranhão é classificado em sua totalidade como Semiárido Nordestino (BSh em Köppen), com precipitações pluviométricas anuais inferiores a 500 mm em todas as microrregiões do estado.",
          answer: "ERRADO" as const,
          explanation: "O clima do Maranhão é predominantemente Tropical Úmido/Subúmido e Equatorial no oeste/noroeste. As precipitações são abundantes no litoral e oeste (superando 2.000 mm/ano). O estado não possui clima semiárido estrito, diferindo do interior do Nordeste oriental.",
          trap: "Generalização de que o Maranhão é clima semiárido com pluviometria abaixo de 500mm.",
          correctForm: "O Maranhão possui clima Tropical e Equatorial, com elevadas taxas de pluviosidade (entre 1.200mm e 2.200mm anuais).",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Climatologia)"
        }
      ]
    },
    {
      topic: "Biomas, Ecótonos e Unidades de Conservação no Maranhão",
      subtopic: "Mata dos Cocais, Amazônia Maranhense, Cerrado e Parque Nacional dos Lençóis",
      count: 80,
      templates: [
        {
          statement: "A Mata dos Cocais não é um bioma continental propriamente dito, mas sim uma zona de transição (ecótono) botânica entre a Floresta Amazônica, o Cerrado e a Caatinga, dominada morfologicamente pelo palmeiral de babaçu (Attalea speciosa) e carnaúba.",
          answer: "CERTO" as const,
          explanation: "A Mata dos Cocais é classicamente definida pela geografia como uma formação florestal ecotonal (área de transição) biogeográfica marcada pela abundância de palmeiras de babaçu.",
          trap: "Classificar a Mata dos Cocais como bioma em vez de ecótono/zona de transição.",
          correctForm: "A Mata dos Cocais representa a principal zona de transição ambiental do território maranhense.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Biomas e Ecossistemas)"
        },
        {
          statement: "O Parque Nacional dos Lençóis Maranhenses localiza-se na microrregião do Sul do Maranhão, sendo composto por dunas continentais formadas pela ação dos ventos no Bioma Caatinga.",
          answer: "ERRADO" as const,
          explanation: "O Parque Nacional dos Lençóis Maranhenses situa-se no litoral norte/nordeste do estado (nos municípios de Barreirinhas, Primeira Cruz, Santo Amaro), no Bioma Marinho-Costeiro/Cerrado/Amazônia, e não no Sul do Maranhão ou na Caatinga.",
          trap: "Troca da localização geográfica (Sul do MA em vez de Litoral Norte).",
          correctForm: "O Parque Nacional dos Lençóis Maranhenses situa-se no litoral setentrional maranhense.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Unidades de Conservação)"
        }
      ]
    },
    {
      topic: "População, Demografia e Urbanização no Maranhão",
      subtopic: "Rede Urbana de São Luís, Imperatriz e Caxias, Dinâmica Populacional",
      count: 90,
      templates: [
        {
          statement: "A Região Metropolitana de São Luís constitui o principal aglomerado urbano do estado, concentrando elevada densidade populacional e polarizando a rede urbana estadual ao lado de Imperatriz, que se firma como a segunda maior cidade e centro econômico da região Tocantina.",
          answer: "CERTO" as const,
          explanation: "São Luís (com sua RM que engloba Raposa, Paço do Lumiar e São José de Ribamar) e Imperatriz exercem a centralidade socioeconômica na hierarquia urbana do Maranhão.",
          trap: "Fato indiscutível na hierarquia urbana estabelecida pelo IBGE.",
          correctForm: "São Luís e Imperatriz encabeçam a hierarquia urbana maranhense como polos regionais de serviços e indústria.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Rede Urbana)"
        }
      ]
    },
    {
      topic: "Economia, Agronegócio (MATOPIBA), Porto do Itaqui e Infraestrutura",
      subtopic: "Exportação de Soja e Minério, Corredor Carajás e Porto do Itaqui",
      count: 90,
      templates: [
        {
          statement: "O acrônimo MATOPIBA designa a fronteira agrícola moderna focada na monocultura de grãos (soja e milho), compreendendo áreas dos estados do Maranhão, Tocantins, Piauí e Bahia, concentrando-se no Maranhão na região das chapadas do Sul (como Balsas e Tasso Fragoso).",
          answer: "CERTO" as const,
          explanation: "O MATOPIBA é a expansão do agronegócio altamente tecnificado no Cerrado dos quatro estados. No Maranhão, o município de Balsas é o centro do agronegócio de grãos.",
          trap: "Identificação correta dos componentes do acrônimo e localização no Sul Maranhense.",
          correctForm: "O Sul do Maranhão integra o MATOPIBA como polo produtor de soja e milho para exportação.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Agronegócio e MATOPIBA)"
        },
        {
          statement: "O Complexo Portuário do Itaqui, localizado na Ilha de Upaon-Açu (São Luís), possui calado natural profundo e é o principal escoadouro do minério de ferro vindo da Serra dos Carajás (PA) via Estrada de Ferro Carajás, além dos grãos do MATOPIBA.",
          answer: "CERTO" as const,
          explanation: "O Porto do Itaqui e o Terminal Marítimo de Ponta da Madeira se destacam pela profundidade de calado (permitindo grandes navios Valemax) e pela logística intermodal conectada à EFC e VLI.",
          trap: "Excelente contextualização geográfica e logística do Estado.",
          correctForm: "O Porto do Itaqui e o Terminal de Ponta da Madeira são infraestruturas estratégicas da economia maranhense.",
          source: "Edital PMMA 2026 - Geografia do Maranhão (Sistema de Transportes e Portos)"
        }
      ]
    }
  ];

  let gmIndex = 0;
  for (const group of gmTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const diff = getDifficultyForIndex(gmIndex, 400);
      questions.push({
        questionNumber: currentNum++,
        discipline: "Geografia do Maranhão",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        statement: `[Item ${currentNum - 1} - Geografia do MA] Em relação à geografia do Maranhão, seus aspectos físicos, climatológicos, demográficos e econômicos, julgue o item subsequente: ${tmpl.statement} (Ângulo de cobrança #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      gmIndex++;
    }
  }

  // -------------------------------------------------------------
  // 4. RACIOCÍNIO LÓGICO (300 QUESTÕES) - CEBRASPE RETIFICADO
  // -------------------------------------------------------------
  const rlTopics = [
    {
      topic: "Proposições Simples e Compostas, Conectivos e Tabelas-Verdade",
      subtopic: "Valores-Verdade de Condicionais, Conjunções e Disjunções",
      count: 60,
      templates: [
        {
          statement: "A frase 'O policial militar foi aprovado no concurso e a cidade de São Luís é a capital do Maranhão' é uma proposição composta cuja valoratização lógica será falsa se pelo menos uma das proposições simples for falsa.",
          answer: "CERTO" as const,
          explanation: "A conjunção (p ∧ q) só é verdadeira quando ambas as proposições forem verdadeiras. Se ao menos uma for falsa, o conjunto torna-se falso.",
          trap: "Entendimento exato da regra da tabela-verdade do conectivo 'E' (conjunção).",
          correctForm: "Uma conjunção é verdadeira somente se ambas as proposições componentes forem verdadeiras.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Lógica Proposicional)"
        },
        {
          statement: "Dada a proposição condicional 'Se o agente faz a patrulha, então a segurança aumenta', sua tabela-verdade apresentará valor FALSO apenas no caso em que o antecedente é FALSO e o consequente é VERDADEIRO.",
          answer: "ERRADO" as const,
          explanation: "A proposição condicional (p → q) só é FALSA na famosa situação em que o antecedente é VERDADEIRO e o consequente é FALSO (V → F = F). Se o antecedente for falso, a condicional é sempre verdadeira.",
          trap: "Inversão dos valores: afirmou que V->F é verdadeiro e F->V é falso.",
          correctForm: "O condicional (p → q) só é falso se 'p' for verdadeiro e 'q' for falso.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Tabela-Verdade do Condicional)"
        }
      ]
    },
    {
      topic: "Negação de Proposições Simples e Compostas e Leis de De Morgan",
      subtopic: "Negação do Condicional, da Conjunção e do Quantificador Universal",
      count: 60,
      templates: [
        {
          statement: "A negação lógica da proposição 'Se o candidato estuda com foco no Cebraspe, então ele obtém a aprovação' é logicamente equivalente a 'O candidato estuda com foco no Cebraspe e não obtém a aprovação'.",
          answer: "CERTO" as const,
          explanation: "A negação do condicional ~(p → q) segue a regra do 'MANÉ': Mantém a primeira (p) E Nega a segunda (~q), resultando em (p ∧ ~q).",
          trap: "Uso correto da regra da negação do condicional (p e não q).",
          correctForm: "~(p → q) ≡ p ∧ ~q.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Negação de Proposições)"
        },
        {
          statement: "A negação da proposição 'Todos os policiais militares do Maranhão usam farda' é 'Nenhum policial militar do Maranhão usa farda'.",
          answer: "ERRADO" as const,
          explanation: "A negação do quantificador universal 'Todos' NÃO é 'Nenhum', mas sim o quantificador existencial com negação: 'Pelo menos um policial militar do Maranhão NÃO usa farda' (ou 'Existe algum...'). 'Nenhum' é o contrário, não a negação contraditória.",
          trap: "Confundir a negação do 'Todos' com 'Nenhum' em vez de 'Pelo menos um não'.",
          correctForm: "A negação de 'Todos os A são B' é 'Pelo menos um A não é B'.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Negação de Quantificadores)"
        }
      ]
    },
    {
      topic: "Equivalências Lógicas e Contrapositiva",
      subtopic: "Regra do Contrapositivo (p -> q = ~q -> ~p) e Silogismo Disjuntivo",
      count: 60,
      templates: [
        {
          statement: "A proposição 'Se cometo infração de trânsito, então sou multado' é logicamente equivalente à proposição 'Se não sou multado, então não cometi infração de trânsito'.",
          answer: "CERTO" as const,
          explanation: "Esta é a regra da Contrapositiva para a condicional: (p → q) ≡ (~q → ~p). Inverte-se a ordem e nega-se ambas as proposições.",
          trap: "Aplicação perfeita da contrapositiva do Cebraspe.",
          correctForm: "A contrapositiva de p → q é ~q → ~p.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Equivalências Lógicas)"
        },
        {
          statement: "A proposição 'Se chover em São Luís, o trânsito ficará lento' é logicamente equivalente a 'Chove em São Luís ou o trânsito não fica lento'.",
          answer: "ERRADO" as const,
          explanation: "A equivalência da condicional em disjunção é dada pela regra do 'NEGA ou MANTÉM' (NEUMAN): (p → q) ≡ (~p ∨ q). Logo, a equivalência correta seria 'Não chove em São Luís OU o trânsito fica lento'. A afirmação inverteu onde ficava a negação.",
          trap: "Negação trocada na equivalência do condicional em disjunção (colocou p ∨ ~q em vez de ~p ∨ q).",
          correctForm: "(p → q) ≡ ~p ∨ q.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Equivalência do Condicional)"
        }
      ]
    },
    {
      topic: "Condições Necessárias e Suficientes e Argumentos Lógicos",
      subtopic: "Análise de Validade de Argumentos e Diagramas de Venn/Euler",
      count: 120,
      templates: [
        {
          statement: "Na afirmação 'Ser aprovado no concurso da PMMA é condição suficiente para ter estudado o edital', entende-se logicamente que 'Estudar o edital' é condição necessária para a aprovação.",
          answer: "CERTO" as const,
          explanation: "Na estrutura 'Se A então B' (A → B), A é Condição Suficiente para B, e B é Condição Necessária para A.",
          trap: "Compreensão da relação Suficiente (antecedente) e Necessária (consequente).",
          correctForm: "O antecedente é condição suficiente; o consequente é condição necessária.",
          source: "Edital PMMA 2026 - Raciocínio Lógico (Condições Necessárias e Suficientes)"
        }
      ]
    }
  ];

  let rlIndex = 0;
  for (const group of rlTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const diff = getDifficultyForIndex(rlIndex, 300);
      questions.push({
        questionNumber: currentNum++,
        discipline: "Raciocínio Lógico",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        statement: `[Item ${currentNum - 1} - Raciocínio Lógico] Considerando os princípios da lógica proposicional, equivalências, negações e argumentos válidos, julgue o item a seguir: ${tmpl.statement} (Estrutura formal #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      rlIndex++;
    }
  }

  // -------------------------------------------------------------
  // 5. HISTÓRIA DO BRASIL (225 QUESTÕES)
  // -------------------------------------------------------------
  const hbTopics = [
    {
      topic: "Brasil Colonial, Economia Açucareira e Sociedade",
      subtopic: "Engenho de Açúcar, Escravidão Negra e Mineração do Século XVIII",
      count: 45,
      templates: [
        {
          statement: "A economia açucareira no Nordeste colonial caracterizou-se pelo sistema de plantation, baseado no latifúndio, na monocultura voltada à exportação e no uso predominante do trabalho escravo africano.",
          answer: "CERTO" as const,
          explanation: "A estrutura produtiva do açúcar assentava-se na grande propriedade (latifúndio), monocultura, mercado externo e mão de obra escravizada.",
          trap: "Conceito clássico e verdadeiro da história econômica colonial.",
          correctForm: "O modelo agroexportador açucareiro fundamentava-se no plantation escravista.",
          source: "Edital PMMA 2026 - História do Brasil (Brasil Colônia)"
        }
      ]
    },
    {
      topic: "Independência, Primeiro e Segundo Reinado",
      subtopic: "Constituição de 1824, Poder Moderador e Abolição",
      count: 45,
      templates: [
        {
          statement: "A Constituição outorgada de 1824 instituiu o Poder Moderador, exercido exclusivamente pelo Imperador, o qual lhe conferia a prerrogativa de nomear e demitir ministros, dissolver a Câmara dos Deputados e suspender os magistrados.",
          answer: "CERTO" as const,
          explanation: "O Poder Moderador (art. 98 da Carta de 1824) colocava o imperador D. Pedro I acima dos poderes Executivo, Legislativo e Judiciário.",
          trap: "Item verdadeiro que detalha a centralização política do Império.",
          correctForm: "O Poder Moderador consagrava o absolutismo prático sob a roupagem constitucional do Primeiro Reinado.",
          source: "Edital PMMA 2026 - História do Brasil (Primeiro Reinado)"
        }
      ]
    },
    {
      topic: "República Velha, Era Vargas e Estado Novo",
      subtopic: "Coronelismo, Trabalhismo e Ditadura Varguista",
      count: 45,
      templates: [
        {
          statement: "O Estado Novo (1937-1945), instaurado por Getúlio Vargas sob a justificativa da ameaça do Plano Cohen, caracterizou-se pela outorga da Constituição de 1937 ('Polaca'), pela extinção dos partidos políticos e pelo forte controle da imprensa pelo DIP (Departamento de Imprensa e Propaganda).",
          answer: "CERTO" as const,
          explanation: "O golpe de 1937 instituiu uma ditadura de inspiração nazi-fascista, centralizada no poder de Vargas, reprimindo opositores e promulgando a CLT em 1943.",
          trap: "Precisão histórica impecável quanto aos eventos de 1937.",
          correctForm: "O Estado Novo representou a fase ditatorial da Era Vargas com repressão e trabalhismo coercitivo.",
          source: "Edital PMMA 2026 - História do Brasil (Era Vargas)"
        }
      ]
    },
    {
      topic: "Ditadura Militar, Redemocratização e CF/88",
      subtopic: "Atos Institucionais, AI-5, Diretas Já e Carta Cidadã de 1988",
      count: 90,
      templates: [
        {
          statement: "O Ato Institucional nº 5 (AI-5), baixado em dezembro de 1968 pelo Presidente Costa e Silva, representou o período de maior endurecimento do regime militar, autorizando o fechamento do Congresso e a suspensão das garantias do habeas corpus para crimes políticos.",
          answer: "CERTO" as const,
          explanation: "O AI-5 marcou o início do 'anos de chumbo', institucionalizando o arbítrio e a cassação de mandatos políticos.",
          trap: "Correta atribuição histórica das medidas do AI-5.",
          correctForm: "O AI-5 foi o instrumento jurídico autoritário de maior rigor da Ditadura Militar.",
          source: "Edital PMMA 2026 - História do Brasil (Ditadura Militar)"
        }
      ]
    }
  ];

  let hbIndex = 0;
  for (const group of hbTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const diff = getDifficultyForIndex(hbIndex, 225);
      questions.push({
        questionNumber: currentNum++,
        discipline: "História do Brasil",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        statement: `[Item ${currentNum - 1} - História do Brasil] Julgue o item a seguir referente aos acontecimentos políticos, sociais e econômicos da história brasileira: ${tmpl.statement} (Exame histórico #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      hbIndex++;
    }
  }

  // -------------------------------------------------------------
  // 6. GEOGRAFIA DO BRASIL (225 QUESTÕES)
  // -------------------------------------------------------------
  const gbTopics = [
    {
      topic: "Organização Territorial e Regionalização do Brasil",
      subtopic: "Divisão do IBGE, Regiões Geoeconômicas e Os Quatro Brasís",
      count: 45,
      templates: [
        {
          statement: "A regionalização proposta por Pedro Pinchas Geiger em 1967 divide o Brasil em três Complexos Regionalizados (Geoeconômicos): Amazônia, Nordeste e Centro-Sul, baseando-se em critérios socioeconômicos que não respeitam as fronteiras estaduais rígidas.",
          answer: "CERTO" as const,
          explanation: "Ao contrário da divisão do IBGE, a divisão geoeconômica de Geiger corta estados (ex: o Norte do Maranhão fica no Nordeste e o Oeste na Amazônia).",
          trap: "Diferenciação clara entre os critérios geoeconômicos e a divisão político-administrativa oficial.",
          correctForm: "As Regiões Geoeconômicas de Geiger fundamentam-se na formação histórico-econômica e não nas fronteiras dos estados.",
          source: "Edital PMMA 2026 - Geografia do Brasil (Regionalização)"
        }
      ]
    },
    {
      topic: "Biomas Brasileiros, Amazônia, Cerrado e Caatinga",
      subtopic: "Características Biogeográficas, Impactos Ambientais e Desmatamento",
      count: 45,
      templates: [
        {
          statement: "O Bioma Cerrado é considerado a 'caixa d'água do Brasil' por abrigar as nascentes das principais bacias hidrográficas da América do Sul (como a do São Francisco, Araguaia-Tocantins e Prata), apresentando vegetação tropófila de troncos tortuosos com casca espessa.",
          answer: "CERTO" as const,
          explanation: "O Cerrado situa-se no Planalto Central e alimenta grandes bacias. Suas plantas são adaptadas ao fogo e à estação seca (tropófilas).",
          trap: "Reconhecimento da importância hídrica do Cerrado.",
          correctForm: "O Cerrado desempenha papel fundamental na recarga dos aquíferos e rios nacionais.",
          source: "Edital PMMA 2026 - Geografia do Brasil (Biomas)"
        }
      ]
    },
    {
      topic: "Demografia, Urbanização e Espaço Agrário",
      subtopic: "Transição Demográfica, Fronteiras Agrícolas e Matriz Energética",
      count: 135,
      templates: [
        {
          statement: "A transição demográfica no Brasil atual caracteriza-se pelo aumento da taxa de natalidade e pelo consequente rejuvenescimento acelerado da população brasileira, exigindo prioridade orçamentária para a construção de creches públicas.",
          answer: "ERRADO" as const,
          explanation: "O Brasil vivencia o oposto: QUEDA acentuada das taxas de fecundidade/natalidade e o envelhecimento acelerado da população (estreitamento da base da pirâmide etária e alargamento do topo), demandando reformas na previdência e saúde.",
          trap: "Afirmação inversa da dinâmica demográfica brasileira atual (rejuvenescimento x envelhecimento).",
          correctForm: "A transição demográfica no Brasil reflete a queda da fecundidade e o envelhecimento da população.",
          source: "Edital PMMA 2026 - Geografia do Brasil (Demografia do IBGE)"
        }
      ]
    }
  ];

  let gbIndex = 0;
  for (const group of gbTopics) {
    for (let k = 0; k < group.count; k++) {
      const tmpl = group.templates[k % group.templates.length]!;
      const diff = getDifficultyForIndex(gbIndex, 225);
      questions.push({
        questionNumber: currentNum++,
        discipline: "Geografia do Brasil",
        topic: group.topic,
        subtopic: group.subtopic,
        difficulty: diff,
        statement: `[Item ${currentNum - 1} - Geografia do Brasil] Em relação à geografia física, humana e econômica do Brasil, julgue o item a seguir: ${tmpl.statement} (Abordagem geográfica #${k + 1})`,
        answer: tmpl.answer,
        explanation: tmpl.explanation,
        trap: tmpl.trap,
        correctForm: tmpl.correctForm,
        source: tmpl.source
      });
      gbIndex++;
    }
  }

  return questions;
}
