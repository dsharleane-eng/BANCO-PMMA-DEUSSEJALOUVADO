import { generateAll2000Questions, type QuestionSeedData } from "./questionDataGenerator";
import { importedQuestions } from "./importedQuestions";

export interface StoredQuestion extends QuestionSeedData {
  id: number;
  createdAt: string;
}

let cache: StoredQuestion[] | null = null;

// The original app persisted these 2,000 deterministic CEBRASPE items in
// PostgreSQL via a seed script. They are generated identically here and kept
// in memory, so the content and ordering are exactly the same.
export function getAllQuestions(): StoredQuestion[] {
  if (!cache) {
    cache = [...generateAll2000Questions(), ...importedQuestions].map((q) => ({
      ...q,
      id: q.questionNumber,
      createdAt: new Date(0).toISOString(),
    }));
  }
  return cache;
}

export function getQuestionByNumber(questionNumber: number): StoredQuestion | undefined {
  return getAllQuestions().find((q) => q.questionNumber === questionNumber);
}
