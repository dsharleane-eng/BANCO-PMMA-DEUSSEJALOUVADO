import { supabase } from "@/integrations/supabase/client";

/**
 * fetch wrapper that attaches the signed-in user's bearer token so the
 * /api routes can scope every read/write to that user (RLS enforced).
 */
export async function apiFetch(input: string, init: RequestInit = {}) {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  const headers = new Headers(init.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  return fetch(input, { ...init, headers });
}
