export type Rating = "again" | "hard" | "good" | "easy";

export interface SrsState {
  ease: number;
  interval_days: number;
  repetitions: number;
  lapses: number;
}

export interface SrsResult extends SrsState {
  due_at: string;
  last_rating: Rating;
}

/**
 * SM-2 (algoritmo do Anki, versão clássica). Intervalos em dias;
 * "again" volta para 10 minutos, como no aprendizado do Anki.
 */
export function scheduleCard(state: SrsState, rating: Rating): SrsResult {
  let { ease, interval_days, repetitions, lapses } = state;
  ease = ease || 2.5;

  if (rating === "again") {
    repetitions = 0;
    lapses += 1;
    ease = Math.max(1.3, ease - 0.2);
    interval_days = 10 / (60 * 24); // 10 minutos
  } else {
    if (rating === "hard") ease = Math.max(1.3, ease - 0.15);
    if (rating === "easy") ease = Math.min(3.0, ease + 0.15);

    if (repetitions === 0) {
      interval_days = rating === "hard" ? 1 : rating === "easy" ? 4 : 1;
    } else if (repetitions === 1) {
      interval_days = rating === "hard" ? 3 : rating === "easy" ? 8 : 6;
    } else {
      const factor = rating === "hard" ? 1.2 : rating === "easy" ? ease * 1.3 : ease;
      interval_days = Math.max(1, interval_days * factor);
    }
    interval_days = Math.min(interval_days, 365);
    repetitions += 1;
  }

  const due = new Date(Date.now() + interval_days * 24 * 60 * 60 * 1000);

  return {
    ease: Number(ease.toFixed(2)),
    interval_days: Number(interval_days.toFixed(4)),
    repetitions,
    lapses,
    due_at: due.toISOString(),
    last_rating: rating,
  };
}

export function formatInterval(days: number): string {
  if (days < 1 / 24) return `${Math.round(days * 24 * 60)}min`;
  if (days < 1) return `${Math.round(days * 24)}h`;
  if (days < 30) return `${Math.round(days)}d`;
  if (days < 365) return `${(days / 30).toFixed(1)} meses`;
  return `${(days / 365).toFixed(1)} anos`;
}
