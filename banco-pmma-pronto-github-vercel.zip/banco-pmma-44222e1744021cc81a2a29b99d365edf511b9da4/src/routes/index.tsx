import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { ShieldAlert, BookOpen, BarChart3, Timer, ArrowRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PMMA 2026 | Banco de Questões CEBRASPE Certo/Errado" },
      {
        name: "description",
        content:
          "Plataforma de estudos para Soldado PMMA 2026: milhares de questões Certo/Errado no padrão CEBRASPE, simulados, maratona, revisão de erros e desempenho por conta.",
      },
      { property: "og:title", content: "PMMA 2026 | Banco de Questões CEBRASPE Certo/Errado" },
      {
        property: "og:description",
        content:
          "Crie sua conta gratuita e estude com questões inéditas, simulados cronometrados e análise de desempenho para a PMMA 2026.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/estudos", replace: true });
    });
  }, [navigate]);

  const features = [
    {
      icon: BookOpen,
      title: "Banco completo de questões",
      text: "Itens Certo/Errado com gabarito comentado, pegadinhas e fundamento legal.",
    },
    {
      icon: Timer,
      title: "Simulados e maratona",
      text: "Provas cronometradas no padrão CEBRASPE com pontuação líquida.",
    },
    {
      icon: BarChart3,
      title: "Desempenho só seu",
      text: "Acertos, erros e caderno de erros vinculados à sua conta, em qualquer aparelho.",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-16 space-y-14">
        <section className="text-center space-y-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg">
            <ShieldAlert className="w-9 h-9 text-white" />
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
            PMMA 2026 • Soldado QP/QPMus
          </h1>
          <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto">
            Estude com o banco de questões inéditas no padrão CEBRASPE, faça simulados
            cronometrados e acompanhe sua evolução com estatísticas pessoais.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/auth"
              className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 rounded-xl text-sm font-bold transition-all"
            >
              Criar conta / Entrar <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-3">
          {features.map((f) => (
            <div
              key={f.title}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-2"
            >
              <f.icon className="w-6 h-6 text-emerald-400" />
              <h2 className="font-bold text-sm">{f.title}</h2>
              <p className="text-xs text-slate-400 leading-relaxed">{f.text}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t border-slate-800 text-slate-500 py-6 text-xs text-center">
        PMMA 2026 • Prova em 11/10/2026
      </footer>
    </div>
  );
}
