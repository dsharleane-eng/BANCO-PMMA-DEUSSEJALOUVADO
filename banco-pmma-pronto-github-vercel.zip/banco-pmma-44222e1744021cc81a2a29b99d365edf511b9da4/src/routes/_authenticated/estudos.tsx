import { createFileRoute, useNavigate } from "@tanstack/react-router";
import React, { useState, useEffect } from "react";
import { LogOut, UserCircle2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { Navbar, type ModeType } from "@/components/pmma/Navbar";
import { BancoMode } from "@/components/pmma/BancoMode";
import { SimuladoMode } from "@/components/pmma/SimuladoMode";
import { RevisaoMode } from "@/components/pmma/RevisaoMode";
import { MaratonaMode } from "@/components/pmma/MaratonaMode";
import { PmmaExamMode } from "@/components/pmma/PmmaExamMode";
import { AnalyticsDashboard } from "@/components/pmma/AnalyticsDashboard";
import { QuestionManager } from "@/components/pmma/QuestionManager";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/_authenticated/estudos")({
  head: () => ({
    meta: [
      { title: "Estudos PMMA 2026 | Banco de Questões CEBRASPE" },
      {
        name: "description",
        content:
          "Área de estudos da PMMA 2026: banco de questões Certo/Errado, simulados, maratona, revisão de erros e estatísticas pessoais de desempenho.",
      },
      { property: "og:title", content: "Estudos PMMA 2026 | Banco de Questões CEBRASPE" },
      {
        property: "og:description",
        content:
          "Resolva questões, faça simulados cronometrados e acompanhe seu desempenho pessoal para o concurso da PMMA 2026.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: EstudosPage,
});

function EstudosPage() {
  const [activeMode, setActiveMode] = useState<ModeType>("BANCO");
  const [totalQuestionsCount, setTotalQuestionsCount] = useState<number>(2000);
  const [initializing, setInitializing] = useState(true);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  useEffect(() => {
    async function initPlatform() {
      try {
        const res = await fetch("/api/seed");
        const data = await res.json();
        if (data.count) setTotalQuestionsCount(data.count);
      } catch (err) {
        console.error("Platform initialization error:", err);
      } finally {
        setInitializing(false);
      }
    }
    initPlatform();
  }, []);

  const handleSignOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-emerald-500 selection:text-white flex flex-col">
      <Navbar
        activeMode={activeMode}
        onSelectMode={setActiveMode}
        totalQuestionsCount={totalQuestionsCount}
      />

      <div className="bg-slate-900 border-b border-slate-800 text-slate-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <UserCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate font-semibold">{user?.email ?? "Carregando..."}</span>
            <span className="hidden sm:inline text-slate-500">
              • seu desempenho é privado e sincronizado entre seus aparelhos
            </span>
          </div>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold"
          >
            <LogOut className="w-3.5 h-3.5" /> Sair
          </button>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {initializing ? (
          <div className="py-24 text-center space-y-4">
            <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">
              Inicializando Plataforma PMMA 2026...
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Verificando banco de questões inéditas e estrutura do banco de dados.
            </p>
          </div>
        ) : (
          <>
            {activeMode === "BANCO" && <BancoMode />}
            {activeMode === "SIMULADO" && <SimuladoMode />}
            {activeMode === "REVISAO" && <RevisaoMode />}
            {activeMode === "MARATONA" && <MaratonaMode />}
            {activeMode === "PMMA" && <PmmaExamMode />}
            {activeMode === "ANALYTICS" && <AnalyticsDashboard />}
            {activeMode === "MANAGER" && <QuestionManager />}
          </>
        )}
      </main>

      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-6 text-xs text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span className="font-bold text-white">PMMA 2026</span> • Banco de Questões Foco
            CEBRASPE (Certo/Errado)
          </div>
          <div className="font-mono text-[11px] text-slate-500">
            Edital Retificado • Soldado QP/QPMus • Prova em 11/10/2026
          </div>
        </div>
      </footer>
    </div>
  );
}
