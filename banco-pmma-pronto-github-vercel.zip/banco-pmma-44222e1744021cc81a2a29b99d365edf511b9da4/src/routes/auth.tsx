import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import React, { useEffect, useState } from "react";
import { ShieldAlert, Mail, Lock, LogIn, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar | PMMA 2026 Banco de Questões" },
      {
        name: "description",
        content:
          "Acesse sua conta ou crie um cadastro gratuito para estudar e acompanhar seu desempenho no banco de questões da PMMA 2026.",
      },
      { property: "og:title", content: "Entrar | PMMA 2026 Banco de Questões" },
      {
        property: "og:description",
        content:
          "Crie sua conta gratuita e acompanhe seu próprio desempenho no banco de questões da PMMA 2026.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/estudos", replace: true });
    });
  }, [navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      if (tab === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/estudos", replace: true });
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/estudos` },
        });
        if (error) throw error;
        if (data.session) {
          navigate({ to: "/estudos", replace: true });
        } else {
          setInfo(
            "Conta criada! Confirme seu e-mail pelo link que enviamos para começar a estudar.",
          );
        }
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro inesperado";
      setError(
        msg.includes("Invalid login credentials")
          ? "E-mail ou senha incorretos."
          : msg.includes("already registered")
            ? "Este e-mail já possui conta. Faça login."
            : msg,
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center space-y-3">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-lg">
            <ShieldAlert className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">PMMA 2026 • Soldado QP/QPMus</h1>
          <p className="text-xs text-slate-400">
            Entre na sua conta para salvar seu desempenho e acessar de qualquer aparelho.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5 shadow-xl">
          <div className="grid grid-cols-2 gap-1 bg-slate-800/70 p-1 rounded-xl">
            {(["login", "signup"] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  setTab(t);
                  setError(null);
                  setInfo(null);
                }}
                className={`py-2 rounded-lg text-xs font-bold transition-all ${
                  tab === t ? "bg-emerald-600 text-white" : "text-slate-300 hover:text-white"
                }`}
              >
                {t === "login" ? "Entrar" : "Criar conta"}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                E-mail
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg text-sm p-2.5 pl-9 text-slate-100"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                Senha
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg text-sm p-2.5 pl-9 text-slate-100"
                />
              </div>
            </div>

            {error && (
              <p className="text-xs font-semibold text-red-400 bg-red-950/40 border border-red-900 rounded-lg p-2.5">
                {error}
              </p>
            )}
            {info && (
              <p className="text-xs font-semibold text-emerald-300 bg-emerald-950/40 border border-emerald-900 rounded-lg p-2.5">
                {info}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all"
            >
              {tab === "login" ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
              {loading ? "Processando..." : tab === "login" ? "Entrar" : "Criar minha conta"}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-slate-500">
          <Link to="/" className="hover:text-slate-300 underline">
            Voltar para a página inicial
          </Link>
        </p>
      </div>
    </div>
  );
}
