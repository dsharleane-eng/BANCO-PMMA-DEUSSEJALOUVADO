import { createFileRoute } from "@tanstack/react-router";
import { getAllQuestions, getQuestionByNumber } from "@/lib/pmmaQuestions.server";
import { getAuthedUser, unauthorized } from "@/lib/apiAuth.server";
import { scheduleCard, type Rating } from "@/lib/srs.server";

const RATINGS: Rating[] = ["again", "hard", "good", "easy"];

export const Route = createFileRoute("/api/flashcards")({
  server: {
    handlers: {
      // Fila de estudo do dia: cartões vencidos primeiro, depois cartões novos.
      GET: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { supabase, userId } = auth;

          const { searchParams } = new URL(request.url);
          const discipline = searchParams.get("discipline");
          const newLimit = parseInt(searchParams.get("newLimit") || "20", 10);
          const dueLimit = parseInt(searchParams.get("dueLimit") || "40", 10);

          const { data: cards, error } = await supabase
            .from("flashcards")
            .select("*")
            .eq("user_id", userId);
          if (error) throw error;

          const nowIso = new Date().toISOString();
          const all = getAllQuestions().filter(
            (q) => !discipline || discipline === "Todas" || q.discipline === discipline,
          );
          const cardMap = new Map((cards || []).map((c) => [c.question_id, c]));

          const dueCards = (cards || [])
            .filter((c) => c.due_at <= nowIso && cardMap.has(c.question_id))
            .filter((c) => {
              const q = getQuestionByNumber(c.question_id);
              return q && (!discipline || discipline === "Todas" || q.discipline === discipline);
            })
            .sort((a, b) => (a.due_at < b.due_at ? -1 : 1))
            .slice(0, dueLimit);

          const newQuestions = all.filter((q) => !cardMap.has(q.questionNumber)).slice(0, newLimit);

          const queue = [
            ...dueCards.map((c) => ({
              question: getQuestionByNumber(c.question_id)!,
              card: {
                ease: c.ease,
                intervalDays: c.interval_days,
                repetitions: c.repetitions,
                lapses: c.lapses,
                dueAt: c.due_at,
                isNew: false,
              },
            })),
            ...newQuestions.map((q) => ({
              question: q,
              card: {
                ease: 2.5,
                intervalDays: 0,
                repetitions: 0,
                lapses: 0,
                dueAt: null,
                isNew: true,
              },
            })),
          ];

          const learning = (cards || []).filter((c) => c.repetitions > 0 && c.interval_days < 21)
            .length;
          const mature = (cards || []).filter((c) => c.interval_days >= 21).length;

          return Response.json({
            queue,
            stats: {
              totalCards: (cards || []).length,
              dueCount: (cards || []).filter((c) => c.due_at <= nowIso).length,
              newCount: Math.max(0, all.length - (cards || []).length),
              learning,
              mature,
              reviewsToday: (cards || []).filter(
                (c) => c.last_reviewed_at && c.last_reviewed_at.slice(0, 10) === nowIso.slice(0, 10),
              ).length,
            },
          });
        } catch (error) {
          console.error("GET /api/flashcards error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },

      // Avaliação de um cartão (Errei / Difícil / Bom / Fácil).
      POST: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { supabase, userId } = auth;

          const body = (await request.json()) as { questionId?: number; rating?: Rating };
          const questionId = body.questionId;
          const rating = body.rating;

          if (!questionId || !rating || !RATINGS.includes(rating)) {
            return Response.json({ error: "questionId e rating são obrigatórios" }, { status: 400 });
          }
          if (!getQuestionByNumber(questionId)) {
            return Response.json({ error: "Question not found" }, { status: 404 });
          }

          const { data: existing } = await supabase
            .from("flashcards")
            .select("*")
            .eq("user_id", userId)
            .eq("question_id", questionId)
            .maybeSingle();

          const next = scheduleCard(
            {
              ease: existing?.ease ?? 2.5,
              interval_days: existing?.interval_days ?? 0,
              repetitions: existing?.repetitions ?? 0,
              lapses: existing?.lapses ?? 0,
            },
            rating,
          );

          const payload = {
            user_id: userId,
            question_id: questionId,
            ease: next.ease,
            interval_days: next.interval_days,
            repetitions: next.repetitions,
            lapses: next.lapses,
            again_count: (existing?.again_count ?? 0) + (rating === "again" ? 1 : 0),
            good_count: (existing?.good_count ?? 0) + (rating === "again" ? 0 : 1),
            last_rating: rating,
            due_at: next.due_at,
            last_reviewed_at: new Date().toISOString(),
          };

          const { error } = await supabase
            .from("flashcards")
            .upsert(payload, { onConflict: "user_id,question_id" });
          if (error) throw error;

          // O flashcard também alimenta o desempenho: "Errei" conta como erro.
          await supabase.from("user_responses").insert({
            user_id: userId,
            question_id: questionId,
            user_answer: getQuestionByNumber(questionId)!.answer,
            is_correct: rating !== "again",
            mode: "FLASHCARD",
            session_id: null,
            time_spent_ms: 0,
          });

          return Response.json({
            success: true,
            card: { ...next, intervalDays: next.interval_days },
          });
        } catch (error) {
          console.error("POST /api/flashcards error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
