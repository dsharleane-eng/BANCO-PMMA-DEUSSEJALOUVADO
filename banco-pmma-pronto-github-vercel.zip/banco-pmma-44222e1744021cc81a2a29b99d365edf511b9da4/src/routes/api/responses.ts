import { createFileRoute } from "@tanstack/react-router";
import { getQuestionByNumber } from "@/lib/pmmaQuestions.server";
import { getAuthedUser, unauthorized } from "@/lib/apiAuth.server";

export const Route = createFileRoute("/api/responses")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { supabase, userId } = auth;

          const body = (await request.json()) as {
            questionId?: number;
            userAnswer?: string;
            mode?: string;
            sessionId?: string | null;
            timeSpentMs?: number;
          };
          const { questionId, userAnswer, mode, sessionId, timeSpentMs } = body;

          if (!Number.isInteger(questionId) || questionId <= 0 || !userAnswer) {
            return Response.json(
              { error: "questionId and userAnswer are required" },
              { status: 400 },
            );
          }

          const question = getQuestionByNumber(questionId);
          if (!question) {
            return Response.json({ error: "Question not found" }, { status: 404 });
          }

          const normalizedAnswer = userAnswer.toUpperCase();
          if (normalizedAnswer !== "CERTO" && normalizedAnswer !== "ERRADO") {
            return Response.json({ error: "userAnswer must be CERTO or ERRADO" }, { status: 400 });
          }

          const correctAnswer = question.answer;
          const isCorrect = normalizedAnswer === correctAnswer.toUpperCase();

          const { data, error } = await supabase
            .from("user_responses")
            .insert({
              user_id: userId,
              question_id: questionId,
              user_answer: normalizedAnswer,
              is_correct: isCorrect,
              mode: mode || "BANCO",
              session_id: sessionId || null,
              time_spent_ms: timeSpentMs || 0,
            })
            .select()
            .single();

          if (error) throw error;

          return Response.json({ success: true, isCorrect, correctAnswer, response: data });
        } catch (error) {
          console.error("POST /api/responses error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
