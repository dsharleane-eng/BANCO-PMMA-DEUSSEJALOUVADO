import { createFileRoute } from "@tanstack/react-router";
import { getAuthedUser, unauthorized } from "@/lib/apiAuth.server";

export const Route = createFileRoute("/api/exam-sessions")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();

          const { data, error } = await auth.supabase
            .from("exam_sessions")
            .select("*")
            .eq("user_id", auth.userId)
            .order("completed_at", { ascending: false })
            .limit(20);

          if (error) throw error;

          const sessions = (data || []).map((s) => ({
            id: s.id,
            mode: s.mode,
            title: s.title,
            totalQuestions: s.total_questions,
            correctCount: s.correct_count,
            incorrectCount: s.incorrect_count,
            blankCount: s.blank_count,
            netScore: s.net_score,
            percentage: s.percentage,
            timeSpentSeconds: s.time_spent_seconds,
            detailsJson: s.details_json,
            completedAt: s.completed_at,
          }));

          return Response.json({ sessions });
        } catch (error) {
          console.error("GET /api/exam-sessions error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
      POST: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { supabase, userId } = auth;

          const body = (await request.json()) as {
            id?: string;
            mode?: string;
            title?: string;
            totalQuestions?: number;
            correctCount?: number;
            incorrectCount?: number;
            blankCount?: number;
            netScore?: number;
            percentage?: number;
            timeSpentSeconds?: number;
            detailsJson?: unknown;
          };

          const { data, error } = await supabase
            .from("exam_sessions")
            .insert({
              user_id: userId,
              id: body.id || `sim_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              mode: body.mode || "SIMULADO",
              title: body.title || "Simulado CEBRASPE",
              total_questions: body.totalQuestions || 0,
              correct_count: body.correctCount || 0,
              incorrect_count: body.incorrectCount || 0,
              blank_count: body.blankCount || 0,
              net_score: body.netScore || 0,
              percentage: body.percentage || 0,
              time_spent_seconds: body.timeSpentSeconds || 0,
              details_json: body.detailsJson ? JSON.stringify(body.detailsJson) : null,
            })
            .select()
            .single();

          if (error) throw error;

          return Response.json({ success: true, session: data });
        } catch (error) {
          console.error("POST /api/exam-sessions error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
