import { createFileRoute } from "@tanstack/react-router";
import { getQuestionByNumber } from "@/lib/pmmaQuestions.server";

export const Route = createFileRoute("/api/questions/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        try {
          const qNum = parseInt(params.id, 10);
          const question = getQuestionByNumber(qNum);
          if (!question) {
            return Response.json({ error: "Question not found" }, { status: 404 });
          }
          return Response.json({ question });
        } catch (error) {
          console.error("GET /api/questions/[id] error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
