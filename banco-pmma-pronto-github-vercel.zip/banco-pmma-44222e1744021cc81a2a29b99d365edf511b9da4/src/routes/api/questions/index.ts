import { createFileRoute } from "@tanstack/react-router";
import { getAllQuestions } from "@/lib/pmmaQuestions.server";
import { getAuthedUser } from "@/lib/apiAuth.server";

export const Route = createFileRoute("/api/questions/")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          const all = getAllQuestions();
          const { searchParams } = new URL(request.url);

          const discipline = searchParams.get("discipline");
          const topic = searchParams.get("topic");
          const difficulty = searchParams.get("difficulty");
          const search = searchParams.get("search");
          const filterStatus = searchParams.get("filterStatus");
          const mode = searchParams.get("mode");
          const page = parseInt(searchParams.get("page") || "1", 10);
          const limit = parseInt(searchParams.get("limit") || "20", 10);
          const random = searchParams.get("random") === "true";
          const questionNumber = searchParams.get("questionNumber");

          const offset = (page - 1) * limit;

          if (questionNumber) {
            const qNum = parseInt(questionNumber, 10);
            const q = all.filter((item) => item.questionNumber === qNum);
            return Response.json({ questions: q, total: q.length, page: 1, totalPages: 1 });
          }

          let items = all;

          if (discipline && discipline !== "Todas") {
            items = items.filter((q) => q.discipline === discipline);
          }
          if (topic && topic !== "Todos") {
            items = items.filter((q) => q.topic === topic);
          }
          if (difficulty && difficulty !== "Todas") {
            items = items.filter((q) => q.difficulty === difficulty);
          }
          if (mode === "MARATONA") {
            const hard = ["Difícil", "Muito Difícil", "Avançado", "Extremamente Difícil"];
            items = items.filter((q) => hard.includes(q.difficulty));
          }
          if (search && search.trim() !== "") {
            const s = search.trim().toLowerCase();
            items = items.filter(
              (q) =>
                q.statement.toLowerCase().includes(s) ||
                q.topic.toLowerCase().includes(s) ||
                q.subtopic.toLowerCase().includes(s) ||
                q.explanation.toLowerCase().includes(s),
            );
          }

          if (filterStatus === "wrong") {
            const { data } = auth
              ? await auth.supabase
                  .from("user_responses")
                  .select("question_id")
                  .eq("user_id", auth.userId)
                  .eq("is_correct", false)
              : { data: [] };
            const qids = new Set((data || []).map((r) => r.question_id));
            if (qids.size === 0) {
              return Response.json({ questions: [], total: 0, page: 1, totalPages: 0 });
            }
            items = items.filter((q) => qids.has(q.questionNumber));
          } else if (filterStatus === "unanswered") {
            const { data } = auth
              ? await auth.supabase
                  .from("user_responses")
                  .select("question_id")
                  .eq("user_id", auth.userId)
              : { data: [] };
            const qids = new Set((data || []).map((r) => r.question_id));
            if (qids.size > 0) {
              items = items.filter((q) => !qids.has(q.questionNumber));
            }
          } else if (filterStatus === "bookmarked") {
            const { data } = auth
              ? await auth.supabase
                  .from("bookmarks")
                  .select("question_id")
                  .eq("user_id", auth.userId)
              : { data: [] };
            const qids = new Set((data || []).map((r) => r.question_id));
            if (qids.size === 0) {
              return Response.json({ questions: [], total: 0, page: 1, totalPages: 0 });
            }
            items = items.filter((q) => qids.has(q.questionNumber));
          }

          const total = items.length;

          let ordered = [...items];
          if (random) {
            for (let i = ordered.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [ordered[i], ordered[j]] = [ordered[j]!, ordered[i]!];
            }
          } else {
            ordered.sort((a, b) => a.questionNumber - b.questionNumber);
          }

          const paged = ordered.slice(offset, offset + limit);
          const questionNumbers = paged.map((q) => q.questionNumber);

          const bookmarkedSet = new Set<number>();
          const latestResponses: Record<number, { isCorrect: boolean; userAnswer: string }> = {};

          if (questionNumbers.length > 0 && auth) {
            const [{ data: bmarks }, { data: resps }] = await Promise.all([
              auth.supabase
                .from("bookmarks")
                .select("question_id")
                .eq("user_id", auth.userId)
                .in("question_id", questionNumbers),
              auth.supabase
                .from("user_responses")
                .select("question_id, is_correct, user_answer, answered_at")
                .eq("user_id", auth.userId)
                .in("question_id", questionNumbers)
                .order("answered_at", { ascending: false }),
            ]);

            (bmarks || []).forEach((b) => bookmarkedSet.add(b.question_id));
            (resps || []).forEach((r) => {
              if (!latestResponses[r.question_id]) {
                latestResponses[r.question_id] = {
                  isCorrect: r.is_correct,
                  userAnswer: r.user_answer,
                };
              }
            });
          }

          const questionsWithStatus = paged.map((q) => ({
            ...q,
            isBookmarked: bookmarkedSet.has(q.questionNumber),
            lastResponse: latestResponses[q.questionNumber] || null,
          }));

          return Response.json({
            questions: questionsWithStatus,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit),
          });
        } catch (error) {
          console.error("GET /api/questions error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
