import { createFileRoute } from "@tanstack/react-router";
import { getAllQuestions } from "@/lib/pmmaQuestions.server";
import { getAuthedUser, unauthorized } from "@/lib/apiAuth.server";

export const Route = createFileRoute("/api/analytics")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const all = getAllQuestions();
          const totalDatabaseQuestions = all.length;
          const qMap = new Map(all.map((q) => [q.questionNumber, q]));

          const { data, error } = await auth.supabase
            .from("user_responses")
            .select("question_id, is_correct, answered_at")
            .eq("user_id", auth.userId)
            .order("answered_at", { ascending: false });
          if (error) throw error;

          const allResponses = (data || [])
            .map((r) => {
              const q = qMap.get(r.question_id);
              if (!q) return null;
              return {
                questionId: r.question_id,
                isCorrect: r.is_correct,
                discipline: q.discipline,
                topic: q.topic,
                subtopic: q.subtopic,
                difficulty: q.difficulty,
              };
            })
            .filter((r): r is NonNullable<typeof r> => r !== null);

          const totalAnsweredAttempts = allResponses.length;

          // Keep only the most recent attempt for each question. The query is
          // ordered newest-first, so the first response we see is authoritative.
          const latestQuestionMap = new Map<number, (typeof allResponses)[0]>();
          allResponses.forEach((resp) => {
            if (!latestQuestionMap.has(resp.questionId)) {
              latestQuestionMap.set(resp.questionId, resp);
            }
          });

          const uniqueAnsweredCount = latestQuestionMap.size;
          const unattemptedCount = Math.max(0, totalDatabaseQuestions - uniqueAnsweredCount);

          let correctCount = 0;
          let incorrectCount = 0;

          const disciplineStats: Record<
            string,
            { total: number; correct: number; incorrect: number }
          > = {
            "Língua Portuguesa": { total: 0, correct: 0, incorrect: 0 },
            "História do Maranhão": { total: 0, correct: 0, incorrect: 0 },
            "Geografia do Maranhão": { total: 0, correct: 0, incorrect: 0 },
            "Raciocínio Lógico": { total: 0, correct: 0, incorrect: 0 },
            "História do Brasil": { total: 0, correct: 0, incorrect: 0 },
            "Geografia do Brasil": { total: 0, correct: 0, incorrect: 0 },
          };

          const topicStats: Record<
            string,
            { discipline: string; total: number; correct: number; incorrect: number }
          > = {};

          const difficultyStats: Record<
            string,
            { total: number; correct: number; incorrect: number }
          > = {
            "Difícil": { total: 0, correct: 0, incorrect: 0 },
            "Muito Difícil": { total: 0, correct: 0, incorrect: 0 },
            "Avançado": { total: 0, correct: 0, incorrect: 0 },
            "Extremamente Difícil": { total: 0, correct: 0, incorrect: 0 },
          };

          latestQuestionMap.forEach((item) => {
            if (item.isCorrect) correctCount++;
            else incorrectCount++;

            if (!disciplineStats[item.discipline]) {
              disciplineStats[item.discipline] = { total: 0, correct: 0, incorrect: 0 };
            }
            const dStat = disciplineStats[item.discipline]!;
            dStat.total++;
            if (item.isCorrect) dStat.correct++;
            else dStat.incorrect++;

            if (!topicStats[item.topic]) {
              topicStats[item.topic] = {
                discipline: item.discipline,
                total: 0,
                correct: 0,
                incorrect: 0,
              };
            }
            const tStat = topicStats[item.topic]!;
            tStat.total++;
            if (item.isCorrect) tStat.correct++;
            else tStat.incorrect++;

            if (!difficultyStats[item.difficulty]) {
              difficultyStats[item.difficulty] = { total: 0, correct: 0, incorrect: 0 };
            }
            const fStat = difficultyStats[item.difficulty]!;
            fStat.total++;
            if (item.isCorrect) fStat.correct++;
            else fStat.incorrect++;
          });

          const netScore = correctCount - incorrectCount;
          const accuracyPercentage =
            uniqueAnsweredCount > 0 ? (correctCount / uniqueAnsweredCount) * 100 : 0;

          const topicList = Object.entries(topicStats).map(([topic, stat]) => {
            const pct = stat.total > 0 ? (stat.correct / stat.total) * 100 : 0;
            return {
              topic,
              discipline: stat.discipline,
              total: stat.total,
              correct: stat.correct,
              incorrect: stat.incorrect,
              percentage: Number(pct.toFixed(1)),
            };
          });

          const weakTopics = topicList
            .filter((t) => t.total >= 1 && t.percentage < 60)
            .sort((a, b) => a.percentage - b.percentage);
          const masteredTopics = topicList
            .filter((t) => t.total >= 1 && t.percentage >= 80)
            .sort((a, b) => b.percentage - a.percentage);
          const needsReviewTopics = topicList
            .filter((t) => t.incorrect > 0)
            .sort((a, b) => b.incorrect - a.incorrect);

          return Response.json({
            totalDatabaseQuestions,
            uniqueAnsweredCount,
            unattemptedCount,
            totalAnsweredAttempts,
            correctCount,
            incorrectCount,
            netScore,
            accuracyPercentage: Number(accuracyPercentage.toFixed(1)),
            disciplineStats,
            difficultyStats,
            weakTopics: weakTopics.slice(0, 10),
            masteredTopics: masteredTopics.slice(0, 10),
            needsReviewTopics: needsReviewTopics.slice(0, 10),
          });
        } catch (error) {
          console.error("GET /api/analytics error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
      DELETE: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { error } = await auth.supabase
            .from("user_responses")
            .delete()
            .eq("user_id", auth.userId);
          if (error) throw error;
          return Response.json({
            success: true,
            message: "Histórico de desempenho zerado com sucesso.",
          });
        } catch (error) {
          console.error("DELETE /api/analytics error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
