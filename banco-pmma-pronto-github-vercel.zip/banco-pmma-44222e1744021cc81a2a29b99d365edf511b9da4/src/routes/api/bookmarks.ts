import { createFileRoute } from "@tanstack/react-router";
import { getQuestionByNumber } from "@/lib/pmmaQuestions.server";
import { getAuthedUser, unauthorized } from "@/lib/apiAuth.server";

export const Route = createFileRoute("/api/bookmarks")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();

          const { data, error } = await auth.supabase
            .from("bookmarks")
            .select("*")
            .eq("user_id", auth.userId)
            .order("created_at", { ascending: false });

          if (error) throw error;

          const combined = (data || []).map((b) => ({
            id: b.id,
            questionId: b.question_id,
            notes: b.notes,
            createdAt: b.created_at,
            question: getQuestionByNumber(b.question_id) || null,
          }));

          return Response.json({ bookmarks: combined });
        } catch (error) {
          console.error("GET /api/bookmarks error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
      POST: async ({ request }) => {
        try {
          const auth = await getAuthedUser(request);
          if (!auth) return unauthorized();
          const { supabase, userId } = auth;

          const { questionId, notes } = (await request.json()) as {
            questionId?: number;
            notes?: string | null;
          };

          if (!questionId) {
            return Response.json({ error: "questionId is required" }, { status: 400 });
          }

          const { data: existing } = await supabase
            .from("bookmarks")
            .select("id")
            .eq("user_id", userId)
            .eq("question_id", questionId)
            .limit(1);

          if (existing && existing.length > 0) {
            await supabase
              .from("bookmarks")
              .delete()
              .eq("user_id", userId)
              .eq("question_id", questionId);
            return Response.json({ success: true, isBookmarked: false });
          }

          const { error } = await supabase
            .from("bookmarks")
            .insert({ user_id: userId, question_id: questionId, notes: notes || null });
          if (error) throw error;

          return Response.json({ success: true, isBookmarked: true });
        } catch (error) {
          console.error("POST /api/bookmarks error:", error);
          const message = error instanceof Error ? error.message : "Internal Server Error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
