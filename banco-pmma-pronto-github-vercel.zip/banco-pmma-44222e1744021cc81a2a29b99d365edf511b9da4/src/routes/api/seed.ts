import { createFileRoute } from "@tanstack/react-router";
import { getAllQuestions } from "@/lib/pmmaQuestions.server";

function seedStatus() {
  const count = getAllQuestions().length;
  return {
    success: true,
    count,
    message: `Banco pronto com ${count} questões inéditas PMMA 2026.`,
  };
}

export const Route = createFileRoute("/api/seed")({
  server: {
    handlers: {
      GET: async () => Response.json(seedStatus()),
      POST: async () => Response.json(seedStatus()),
    },
  },
});
