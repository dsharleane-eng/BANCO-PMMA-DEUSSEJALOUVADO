export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      bookmarks: {
        Row: {
          created_at: string
          id: number
          notes: string | null
          question_id: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: number
          notes?: string | null
          question_id: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: number
          notes?: string | null
          question_id?: number
          user_id?: string
        }
        Relationships: []
      }
      exam_sessions: {
        Row: {
          blank_count: number
          completed_at: string
          correct_count: number
          details_json: string | null
          id: string
          incorrect_count: number
          mode: string
          net_score: number
          percentage: number
          time_spent_seconds: number
          title: string
          total_questions: number
          user_id: string
        }
        Insert: {
          blank_count: number
          completed_at?: string
          correct_count: number
          details_json?: string | null
          id: string
          incorrect_count: number
          mode: string
          net_score: number
          percentage: number
          time_spent_seconds: number
          title: string
          total_questions: number
          user_id: string
        }
        Update: {
          blank_count?: number
          completed_at?: string
          correct_count?: number
          details_json?: string | null
          id?: string
          incorrect_count?: number
          mode?: string
          net_score?: number
          percentage?: number
          time_spent_seconds?: number
          title?: string
          total_questions?: number
          user_id?: string
        }
        Relationships: []
      }
      flashcards: {
        Row: {
          again_count: number
          created_at: string
          due_at: string
          ease: number
          good_count: number
          id: number
          interval_days: number
          lapses: number
          last_rating: string | null
          last_reviewed_at: string | null
          question_id: number
          repetitions: number
          updated_at: string
          user_id: string
        }
        Insert: {
          again_count?: number
          created_at?: string
          due_at?: string
          ease?: number
          good_count?: number
          id?: number
          interval_days?: number
          lapses?: number
          last_rating?: string | null
          last_reviewed_at?: string | null
          question_id: number
          repetitions?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          again_count?: number
          created_at?: string
          due_at?: string
          ease?: number
          good_count?: number
          id?: number
          interval_days?: number
          lapses?: number
          last_rating?: string | null
          last_reviewed_at?: string | null
          question_id?: number
          repetitions?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_responses: {
        Row: {
          answered_at: string
          id: number
          is_correct: boolean
          mode: string
          question_id: number
          session_id: string | null
          time_spent_ms: number | null
          user_answer: string
          user_id: string
        }
        Insert: {
          answered_at?: string
          id?: number
          is_correct: boolean
          mode: string
          question_id: number
          session_id?: string | null
          time_spent_ms?: number | null
          user_answer: string
          user_id: string
        }
        Update: {
          answered_at?: string
          id?: number
          is_correct?: boolean
          mode?: string
          question_id?: number
          session_id?: string | null
          time_spent_ms?: number | null
          user_answer?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
