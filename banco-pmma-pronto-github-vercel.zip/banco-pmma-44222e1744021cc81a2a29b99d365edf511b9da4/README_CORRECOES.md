# Banco PMMA — correções aplicadas

Esta versão foi baseada no projeto original exportado do GitHub/Lovable. As áreas que já estavam funcionando foram preservadas.

## Correções

- Corrigida a autenticação das rotas da API para validar o token do usuário com `supabase.auth.getUser(token)`; isso evita que as gravações de respostas e a leitura do desempenho sejam tratadas como não autenticadas.
- Corrigido o cálculo do desempenho para considerar deterministically a resposta mais recente de cada questão, usando `answered_at`.
- Mantidos os registros de tentativas, com `totalAnsweredAttempts` separado de `uniqueAnsweredCount`.
- Corrigidos imports quebrados que estavam inserindo um `import` dentro de outro em vários componentes PMMA.
- Corrigido o painel para usar o total real de questões retornado pela aplicação, sem deixar 2.000 fixo na interface.
- Reconstruído o Modo Flashcard para usar a API `/api/flashcards`, mostrar fila de novos/vencidos/aprendendo/maduros, revelar gabarito/comentário e registrar as avaliações `Errei/Difícil/Bom/Fácil`.
- O flashcard avaliado é removido da fila atual para evitar ficar preso no mesmo cartão.
- Adicionado `.env.example` e proteção de `.env` no `.gitignore`.

## Importante

O arquivo `.env` original não deve ser publicado em um novo repositório. Configure as variáveis do `.env.example` na hospedagem.
