# Banco PMMA

Aplicação web de estudo e banco de questões.

## Desenvolvimento

```bash
npm install
npm run dev
```

## Build de produção

```bash
npm run build
npm run start
```

## Variáveis de ambiente

Configure as variáveis do `.env.example` no ambiente local e na plataforma de deploy.
